
/*-- Global Variable Declarations --*/

/* Local Server */
//var webServiceURL = "http://172.16.11.67:800/IOTimeSheetsServices.svc/restful/";

/*sarmick system ip*/
//var webServiceURL = "http://172.16.11.242:800/IOTimeSheetsServices.svc/restful/";

/*shankar*/
//var webServiceURL = "http://123.255.250.197:2239/IOTimeSheetsServices.svc/restful/";

/* Staging Server */
var webServiceURL = "http://202.129.196.131:800/IOTimeSheetsServices.svc/restful/";

var db;
var parameter;
var i;
var j=0;
var jobName;
var taskName;
var units;
var lineNumber;
var str;
var now;
var day;
var month;
var currentDate;
var fullDate;
var submitFullDate;
var year;
var timeSheetStatus;
var hoursTypeListArray = [];
var jobListArray = [];
var taskListArray = [];
var taskListArrayAutoComplete = [];
var jobno;
var fromViewPg = 0;
var first;
var last;
var firstFullDate;
var lastFullDate;
var fortNightDays;
var timeSheetSavedFrom;
var hoursTypeTextFieldValue;
var jobListTextFieldValue;
var taskListTextFieldValue;
var payRollPeriodStartingDate;
var payRollPeriodEndingDate;
var payRollPeriods = [];
var yesterday;
var HoursPerWeek;
var timeSheetEmpName;
var empWorkedHours;
var fromPg;
var frm = 0;
var weeklyPeriod;
var weeklyPeriodSplit;
var pwdRegEx = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@!*#?&^_.:~`|])[A-Za-z\d$@!*#?&^_.:~`|]{8,}$/;
var hoursUnits = /^[0-9]*\.[0-9]{2}$/;
var popUpDeleteIcon;
var plantEntryNo;
var simpleList;
var submittedList;
var approvedList;
var rejectedList;
var generatingTimesheetListViewType;
var noOfPlantEntry;

/*-- Device Ready Function Call Everytime When App Lauches --*/

document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
    
//    if(localStorage.getItem("firstLogin") == null){
//    localStorage.setItem("firstLogin","0");
//    $.mobile.changePage("#timeSheetPreviewPg", {
//                        transition: "fade",
//                        changeHash: false
//                        });
//    }else{
//        changePage("#timeSheetLoginPg","slide",true);
//    }

    StatusBar.styleLightContent();
    StatusBar.overlaysWebView(false);
    StatusBar.backgroundColorByHexString("#375BAA");
    
}

/* function initiate(){
    $("#popupParisTwo, #popupParisThree").hide();
}

$("#popupParis").on("swipeleft", function(){
                               $("#popupParis").hide();
                               $("#popupParisTwo").show();
                               });

$("#popupParisTwo").on("swipeleft", function(){
                       $("#popupParisTwo").hide();
                       $("#popupParisThree").show();
                    });

$("#popupParisThree").on("swipeleft", function(){
                         $.mobile.changePage("#timeSheetLoginPg", {
                                             transition: "fade",
                                             changeHash: false
                                             });
                         changePage("#timeSheetLoginPg","slide",true);
                       });
*/

/*-- Resume Function Calls Everytime When App Lauches from background --*/

document.addEventListener("resume", appWhenResumedFromBackground, false);

/*-- Function to change to login page when app restore from background location --*/

function appWhenResumedFromBackground(){

    changePage("#timeSheetLoginPg", "slide", true);
    $("#timeSheetPlantEntry").prop("checked",false).checkboxradio("refresh");
}

/*-- Function Calls When User Press Android BackButton --*/

/* 
 document.addEventListener("deviceready", androidBackButtonPress, false);

function androidBackButtonPress(e){
    
    if(device.platform == "android" || device.platform == "Android"){
        if(type=="submit"){
            e.preventDefault();
        }
        
    }
}
 */

/*-- Pagecontainershow --*/

/*-- Function Call Based On Page ID --*/

$(document).on("pagecontainershow", function(event, ui) {
               
               var activePage = $.mobile.pageContainer.pagecontainer("getActivePage");
               
               activePageName = activePage.attr('id');
               
               switch (activePage.attr('id')) {
//               case 'timeSheetPreviewPg':
//               initiate();
//               break;
//               case 'timeSheetLoginPg':
//               clearAllFieldsOfLoginPg();
//               break;
               case 'timeSheetChangePasswordPg':
               clearAllFieldsOfChangePwdPg();
               break;
               case 'timeSheetPg':
               timeSheetEmptyFromToDateField();
               break;
               case 'timeSheetButtonPg':
               getEmpDetails();
               break;
               }
               });

/*-- Pagecontainershow End --*/

/*-- Common Method To Shows Dialog Box --*/

function showAlert(alertmessage, title, callBack_func) {
    if (callBack_func) {
        navigator.notification.alert(alertmessage, callBack_func, title, "OK");
    } else {
        navigator.notification.alert(alertmessage, false, title, "OK");
    }
}

/*-- Dialog Box Method End --*/

/*-- Common Prompt Alert --*/

function promptAlert(alertmessage, callBack_func, title, buttonLabels1, buttonLabels2) {
    
    if (callBack_func) {
        navigator.notification.confirm(alertmessage, callBack_func, title, [buttonLabels1, buttonLabels2]);
    } else {
        navigator.notification.confirm(alertmessage, false, title, [buttonLabels1, buttonLabels2]);
    }
}

/*-- End Common Prompt Alert --*/


/*-- Common Prompt Alert --*/

function multiplePromptAlert(alertmessage, callBack_func, title, buttonLabels1, buttonLabels2, buttonLabels3) {
    
    if (callBack_func) {
        navigator.notification.confirm(alertmessage, callBack_func, title, [buttonLabels1, buttonLabels2, buttonLabels3]);
    } else {
        navigator.notification.confirm(alertmessage, false, title, [buttonLabels1, buttonLabels2, buttonLabels3]);
    }
}

/*-- End Common Prompt Alert --*/

/*-- ChangePage Function --*/

function changePage(pagename, pageTransition, isReverse) {
    
    $.mobile.changePage(pagename, {
                        transition: pageTransition,
                        changeHash: false,
                        reverse: isReverse
                        });
    
}

/*-- End of ChangePage Function --*/


/*-- Method To Check Internet Connection --*/

function checkConnection() {
    
    var networkState = navigator.connection.type;
    var states = {};
    states[Connection.UNKNOWN] = 'Unknown connection';
    states[Connection.ETHERNET] = 'Ethernet connection';
    states[Connection.WIFI] = 'WiFi connection';
    states[Connection.CELL_2G] = 'Cell 2G connection';
    states[Connection.CELL_3G] = 'Cell 3G connection';
    states[Connection.CELL_4G] = 'Cell 4G connection';
    states[Connection.NONE] = 'No network connection';
    if (states[networkState] == 'No network connection') {
        return false;
    } else {
        return true;
    }
}

/*-- End of Internet Connection Method --*/


/*-- Common Method To Show Loading Icon While Calling Webservice  --*/

function Apploadingicon() {
    
    $("body").append("<div class='modalWindow'/>");
    $("body").bind("touchmove", function(e) {
                   e.preventDefault()
                   });
    
    $.mobile.loading("show", {
                     text: "Loading...",
                     textVisible: true,
                     theme: "b",
                     html: ""
                     });
    
}

/*-- End Of Loading Icon Method --*/


/*-- Method To Hide App Loading Icon --*/

function hideLoadingIcon() {
    
    $("body").unbind("touchmove");
    $(".modalWindow").remove();
    $.mobile.loading("hide");
    
}

/*-- End Of Method App Loading Icon --*/


/*-- Exception Handling Method --*/

function errorHandling(originalCode) {
    try {
        originalCode();
    } catch (err) {
        alert(err.message);
    }
}

/*-- End Of Exception Handling Block --*/


/*-- Common Method To Call WebService  --*/

function timeSheetWebService(requestType, methodName, param, callBack) {
    
    errorHandling(function() {
                  Apploadingicon();
                  if (checkConnection()) {
                  $.ajax({
                         type: "" + requestType + "",
                         url: webServiceURL + "" + methodName + "",
                         data: JSON.stringify(param),
                         dataType: "json",
                         contentType: "application/json; charset=utf-8",
                         success: function(msg) {
                         callBack(msg);
                         },
                         error: function(xhr) {
                         console.log(JSON.stringify(xhr));
                         showAlert("Webservice Error", "Timesheet");
                         hideLoadingIcon();
                         /* To uncheck platn entry checkbox */
                         $("#timeSheetPlantEntry").prop("checked",false).checkboxradio("refresh");
                         }
                         });
                  } else {
                  showAlert("Please check internet connection.", "Timesheet");
                  hideLoadingIcon();
                  }
                  });
}

/*-- End Of Common WebService Method --*/


/*-- Logout Function --*/

function timeSheetLogout(){
    Apploadingicon();
    promptAlert("Are you sure you want to logout?", logout, "Timesheet", "Yes", "No");
}

function logout(btnIndex){
    if(btnIndex==1){
        hideLoadingIcon();
        changePage("#timeSheetLoginPg", "slide", true);
    }else{
        hideLoadingIcon();
        //console.log("stay in same page");
    }
    
}

/*-- End Of Logout Function --*/


/*-- Clear all fields of changepassword screen */

function clearAllFieldsOfChangePwdPg(){
    $("#timeSheetOldPwd").val("");
    $("#timeSheetNewPwd").val("");
    $("#timeSheetConfirmNewPwd").val("");
}

/*-- End Of Function --*/

/*-- Change Password Function */

function timeSheetChangePassword(){
    
    if(($("#timeSheetOldPwd").val()== "") && ($("#timeSheetNewPwd").val()== "") && ($("#timeSheetConfirmNewPwd").val()== "")){
        showAlert("Please enter all fields.","Timesheet", function(){
                  $("#timeSheetOldPwd").focus();
                  });
    }else if($("#timeSheetOldPwd").val()== ""){
        showAlert("Please enter old password.","Timesheet", function(){
                  $("#timeSheetOldPwd").focus();
                  });
    }else if($("#timeSheetNewPwd").val()== ""){
        showAlert("Please enter new password.","Timesheet", function(){
                  $("#timeSheetNewPwd").focus();
                  });
    }else if($("#timeSheetConfirmNewPwd").val()== ""){
        showAlert("Please enter confirm password.","Timesheet", function(){
                  $("#timeSheetConfirmNewPwd").focus();
                  });
    }else if(!(pwdRegEx.test($("#timeSheetConfirmNewPwd").val()))){
        showAlert("Password should have atlease one alphabet, one special symbols/characters and minimum of 8 characters.","Timesheet");
    }else if($("#timeSheetOldPwd").val() != localStorage.getItem("timeSheetPassword")){
         showAlert("Old Password is not correct.","Timesheet");
    }else {
        
        if($("#timeSheetNewPwd").val() != $("#timeSheetConfirmNewPwd").val()){
            showAlert("New password & confirm password doesn't match.","Timesheet");
        }else{
        
        parameter = {"employee":{
            "EmployeeNo": localStorage.getItem("timeSheetEmployeeNumber"),
            "Password": $("#timeSheetOldPwd").val(),
            "CurrentPassword":$("#timeSheetNewPwd").val()
        }}
            
        timeSheetWebService("POST", "ChangeCurrentPassword", parameter, function(response) {
                               //console.log(JSON.stringify(parameter));
                               // console.log("ChangeCurrentPassword"+JSON.stringify(response));
                                if (response.ChangeCurrentPasswordResult) {
                                hideLoadingIcon();
                                showAlert("Password changed successfully.", "Timesheet", function(){
                                changePage("#timeSheetLoginPg","slide",true);
                                      });
                                } else {
                                hideLoadingIcon();
                                showAlert("Unable to change password please tryagain later.", "Timesheet");
                                }
                            
                                });
        }
            
        }
    }


/*-- End Of Change Password Function --*/

/*--Function To Clear All Fields Of Login Page--*/

function clearAllFieldsOfLoginPg()
{
    /*-- Code to change the theme color while login and logout--*/
    
    if(($("#timeSheetsTheme").val())=="template1"){
        $(".ui-btn, .ui-header").css({"background-color":"#74203f","color":"#ffffff","text-shadow":"none","border-color":"#74203f"});
        $(".timeSheetsTheme").css({"color":"#74203f"});
    }else if(($("#timeSheetsTheme").val())=="default"){
        $(".ui-btn, .ui-header").css({"background-color":"#375BAA","color":"#ffffff","text-shadow":"none","border-color":"#375BAA"});
        $(".timeSheetsTheme").css({"color":"#375BAA"});
    }
    
    $("#timeSheetLoginPgUserName").val("");
    $("#timeSheetLoginPgPassword").val("");
}

/*-- End Of Function --*/


/*-- Timesheet Function To Change Theme Throught The Application --*/

function timeSheetThemeChange(){
    
    if(($("#timeSheetsTheme").val())=="template1"){
        $("[data-role=page]").page({theme:"a"});
        StatusBar.backgroundColorByHexString("#74203f");
        $(".timeSheetPlantEntryHeading").css("background-color","#74203f");
        $(".viewAllTimesheetStyle, label").css("color","#74203f");
        $(".timeSheetEmpName, .timeSheetMinWrkingHrs, .timeSheetMaxWrkingHrs").css("color","#74203f");
        $(".ui-btn").css({"background-color":"#74203f","color":"#ffffff","text-shadow":"none","border-color":"#74203f"});
        $(".ui-header").css({"background-color":"#74203f","color":"#ffffff","border-color":"#74203f","text-shadow":"none"});
        $(".ui-input").css("color","#1D1D1D");
        $(".ui-select, .ui-btn, select").css("border-color","#ffffff");
        $(".infoIcon").css({"background-color":"#74203f","border-color":"#74203f"});

    }else if(($("#timeSheetsTheme").val())=="default"){
        
        $("[data-role=page]").page({theme:"a"});
        StatusBar.backgroundColorByHexString("#375BAA");
        $(".timeSheetPlantEntryHeading").css("background-color","#375BAA");
        $(".viewAllTimesheetStyle, label").css("color","#375BAA");
        $(".timeSheetEmpName,.timeSheetMinWrkingHrs,.timeSheetMaxWrkingHrs").css("color","#375BAA");
        $(".ui-btn").css({"background-color":"#375BAA","color":"#ffffff","text-shadow":"none","border-color":"#375BAA"});
        $(".ui-header").css({"background-color":"#375BAA","color":"#ffffff","border-color":"#375BAA","text-shadow":"none"});
        $(".ui-input").css("color","#ffffff");
        $(".ui-select, .ui-btn, select").css("border-color","#ffffff");
        $(".infoIcon").css({"background-color":"#375BAA","border-color":"#375BAA"});
    }
    
}

/*-- End Of Function --*/

/*-- Timesheet Login Function --*/

function timesheetLogin(){
    
//    fromPg = $.mobile.activePage.attr("id");
    if($("#timeSheetLoginPgUserName").val()==""||$("#timeSheetLoginPgUserName").val()==" "||$("#timeSheetLoginPgUserName").val()==undefined || $("#timeSheetLoginPgUserName").val()== null){
        showAlert("Please enter your Username.","Timesheet", function(){
                  $("#timeSheetLoginPgUserName").focus();
                  });
    }else if($("#timeSheetLoginPgPassword").val()==""||$("#timeSheetLoginPgPassword").val()==" "||$("#timeSheetLoginPgPassword").val()==undefined || $("#timeSheetLoginPgPassword").val()== null){
        showAlert("Please enter your Password.","Timesheet", function(){
                  $("#timeSheetLoginPgPassword").focus();
                  });
    }else{
        
        if(($("#timeSheetsTheme").val())=="template1"){
                       $("[data-role=page]").page({theme:"a"});
                       StatusBar.backgroundColorByHexString("#74203f");
                       $(".timeSheetPlantEntryHeading").css("background-color","#74203f");
                       $(".viewAllTimesheetStyle, label").css("color","#74203f");
                       $(".timeSheetEmpName, .timeSheetMinWrkingHrs, .timeSheetMaxWrkingHrs").css("color","#74203f");
                       $(".ui-btn").css({"background-color":"#74203f","color":"#ffffff","text-shadow":"none","border-color":"#74203f"});
                       $(".ui-header").css({"background-color":"#74203f","color":"#ffffff","border-color":"#74203f","text-shadow":"none"});
                       $(".ui-input").css("color","#1D1D1D");
                       $(".ui-select, .ui-btn, select").css("border-color","#ffffff");
                       $(".infoIcon").css({"background-color":"#74203f","border-color":"#74203f"});
            
            
            /*-- Orange:  RGB {255:127:0}  HEX: FF7F00
             Blue: RGB {55:91:170}  HEX: 375BAA --- 007CDE - outlook color --*/
            
        }else if(($("#timeSheetsTheme").val())=="default"){
            
                        $("[data-role=page]").page({theme:"a"});
                        StatusBar.backgroundColorByHexString("#375BAA");
                        $(".timeSheetPlantEntryHeading").css("background-color","#375BAA");
                        $(".viewAllTimesheetStyle, label").css("color","#375BAA");
                        $(".timeSheetEmpName,.timeSheetMinWrkingHrs,.timeSheetMaxWrkingHrs").css("color","#375BAA");
                        $(".ui-btn").css({"background-color":"#375BAA","color":"#ffffff","text-shadow":"none","border-color":"#375BAA"});
                        $(".ui-header").css({"background-color":"#375BAA","color":"#ffffff","border-color":"#375BAA","text-shadow":"none"});
                        $(".ui-input").css("color","#ffffff");
                        $(".ui-select, .ui-btn, select").css("border-color","#ffffff");
                        $(".infoIcon").css({"background-color":"#375BAA","border-color":"#375BAA"});
            
                    }
        
        /* code to find 1st and last day of the current week */
        
        timeSheetSavedFrom = "weekly";
        now = new Date();
        first = now.getDate() - now.getDay();
        first = new Date(now.setDate(first)).toUTCString();
        
        //last = new Date(now.setDate(last)).toUTCString();
        
        /* Code to find 1st day of week */
        
        firstFullDate = new Date(first);
        lastFullDate = new Date(first);
        
        day = firstFullDate.getDate()+1;
        weeklyStartDate = firstFullDate .getDate();
        if(day<10){
            day = "0"+day;
        }
        
        month = firstFullDate.getMonth()+1;
        if(month<10){
            
            month = "0"+month;
        }
        
        year = firstFullDate.getFullYear();
        firstFullDate = day+"-"+month+"-"+year;
        
        /* Code to find last day of week*/
        
        lastFullDate.setDate(lastFullDate.getDate() + 6);
        day = lastFullDate.getDate()+1;
        month = lastFullDate.getMonth() + 1;
        year = lastFullDate.getFullYear();
        
        if(day<10){
            day = "0"+day;
        }
        
        if(month<10){
            month = "0"+month;
        }
        
        lastFullDate = day+"-"+month+"-"+year;
        
        parameter = {
            "employee":{
            "EmployeeNo": $("#timeSheetLoginPgUserName").val(),
            "Password": $("#timeSheetLoginPgPassword").val(),
            "frmDate":firstFullDate,
            "toDate":lastFullDate
        }
        }
        
        localStorage.setItem("currentWeekFirstDate",firstFullDate);
        localStorage.setItem("currentWeekLastDate",lastFullDate);
        
        timeSheetWebService("POST", "GetEmployee", parameter, function(response) {
                   console.log("Login"+JSON.stringify(response));
                   if (response.GetEmployeeResult.Status) {
                   localStorage.setItem("timeSheetEmployeeNumber",$("#timeSheetLoginPgUserName").val());
                   localStorage.setItem("timeSheetPassword",$("#timeSheetLoginPgPassword").val());
                   localStorage.setItem("timeSheetPayRollNumber",response.GetEmployeeResult.PayrollNumber);
                   empWorkedHours = response.GetEmployeeResult.TotalUnits;
                   timeSheetEmpName = response.GetEmployeeResult.FullName;
                   HoursPerWeek = response.GetEmployeeResult.HoursPerWeek;
                   hideLoadingIcon();
                   changePage("#timeSheetButtonPg","slide",false);
                   } else {
                   hideLoadingIcon();
                   showAlert("Invalid Username or Password.", "Timesheet");
                   }
                            });
    }
}

/*-- End Of Login Function --*/

/*-- Forgot Password Function --*/

function timsheetForgotPwd(){
    
    navigator.notification.prompt("Please enter your Employee No", sendEmail, "Forgot Password", ["Send Mail","Cancel"], "");

}

function sendEmail(res){
    if(res.buttonIndex == 1){
        
         parameter = {
                "employeeno":res.input1
            }
        console.log(JSON.stringify(parameter));
            timeSheetWebService("POST", "PasswordResetEmail", parameter, function(response) {
                                
                                if((response.PasswordResetEmailResult.Status)){
                                hideLoadingIcon();
                                showAlert("Password sent to your mail.","Timesheet");
                                }else{
                                hideLoadingIcon();
                                showAlert("Couldn't able to send password to your mail, please try again.","Timesheet");
                                }
                                });
        
    }else{
        console.log("no op")
    }
    
    
}

/*-- End Of Login Function --*/

/*-- Function to modify worked hours and hoursperweek --*/
function getEmpDetails(){
    
    $(".timeSheetEmpName").text(timeSheetEmpName);
    $(".timeSheetMinWrkingHrs").text("Min Hrs: "+HoursPerWeek);
    
    if(empWorkedHours==undefined || empWorkedHours==null){
        $(".timeSheetMaxWrkingHrs").text("Hrs Worked: 0");
    }else{
        $(".timeSheetMaxWrkingHrs").text("Hrs Worked: " + empWorkedHours);
    }
    
}

/*-- End Of Login Function --*/

/*-- Timesheet Clear Filter Date Fields Function & get payperiods selectbox value i.e month details --*/

function timeSheetEmptyFromToDateField(){
//    $("#timeSheetPgFrom").val("");
//    $("#timeSheetPgTo").val("");
    
    $("#timeSheetPgFrom").val(localStorage.getItem("searchFromDate"));
    $("#timeSheetPgTo").val(localStorage.getItem("searchToDate"));
    
    $("#timeSheetPgWeeklyPeriod").empty("");
    $("#timeSheetPgWeeklyPeriod").append("<option value='0'>Weekly Periods</option>");
    $("#timeSheetPgWeeklyPeriod").selectmenu().selectmenu("refresh");
    
    parameter = {
        "payrollNumber":localStorage.getItem("timeSheetPayRollNumber")
    }
    
    timeSheetWebService("POST", "GetPayrollPeriods", parameter, function(response) {
                        //console.log(JSON.stringify(parameter));
                        //console.log("GetPayrollPeriods"+JSON.stringify(response));
                        if ((response.GetPayrollPeriodsResult == null) || (response.GetPayrollPeriodsResult == "") || (response.GetPayrollPeriodsResult == undefined)){
                        hideLoadingIcon();
                        showAlert("Pay Periods not found please tryagin later.", "Timesheet");
                        }else{

                        for(i=0;i<response.GetPayrollPeriodsResult.length;i++){
                        
                        str = response.GetPayrollPeriodsResult[i].StartingDate;
                        str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                        now = new Date(+str);
                        day = ("0" + now.getDate()).slice(-2);
                        month = ("0" + (now.getMonth() + 1)).slice(-2);
                        payRollPeriodStartingDate = day+"-"+month+"-"+now.getFullYear();
                        
                        str = response.GetPayrollPeriodsResult[i].EndingDate;
                        str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                        now = new Date(+str);
                        day = ("0" + now.getDate()).slice(-2);
                        month = ("0" + (now.getMonth() + 1)).slice(-2);
                        payRollPeriodEndingDate = day+"-"+month+"-"+now.getFullYear();
                        
                        payRollPeriods[i] = {"startingDate":payRollPeriodStartingDate, "endingDate":payRollPeriodEndingDate, "IsCurrent":response.GetPayrollPeriodsResult[i].IsCurrent, "IsLocked":response.GetPayrollPeriodsResult[i].IsLocked, "Number":now.getFullYear()+""+response.GetPayrollPeriodsResult[i].Number};
                        
                        }
                        $("#timeSheetPgPayRollPeriod").empty("");
                        $("#timeSheetPgPayRollPeriod").append("<option value='0'>Payroll Periods</option>");
                        for(i=0;i<payRollPeriods.length;i++){
                        
                        $("#timeSheetPgPayRollPeriod").append("<option value="+payRollPeriods[i].Number+">"+payRollPeriods[i].startingDate+" to "+payRollPeriods[i].endingDate+"</option>");
                        $("#timeSheetPgPayRollPeriod").selectmenu().selectmenu("refresh");
                        }
                        if(localStorage.getItem("payRollPeriod") != ""){
                        $("#timeSheetPgPayRollPeriod option[value="+localStorage.getItem('payRollPeriod')+"]").prop("selected", "selected").change();
                        $("#timeSheetPgPayRollPeriod").selectmenu().selectmenu("refresh");
                        }
                        hideLoadingIcon();
                        }
                        });
    
}

/*-- End Of Clear Filter Date Fields Function --*/

/*-- Depending on the payperiod month the weekly period will be generated--*/

$("#timeSheetPgPayRollPeriod").change(function (){
        
        parameter = { "payPeriod":$("#timeSheetPgPayRollPeriod :selected").text() }
                                      
        if($("#timeSheetPgPayRollPeriod :selected").text()=="Payroll Periods"){
                                      $("#timeSheetPgWeeklyPeriod").empty("");
                                      $("#timeSheetPgWeeklyPeriod").append("<option value='0'>Weekly Periods</option>");
                                      $("#timeSheetPgWeeklyPeriod").selectmenu("refresh", true);
        }else{
                                      
        timeSheetWebService("POST", "GetWeeksforPayPeriod", parameter, function(response) {
                
                //console.log(JSON.stringify(parameter));
                //console.log("asfdasdf"+JSON.stringify(response));
                            
                            if ((response.GetWeeksforPayPeriodResult == null) || (response.GetWeeksforPayPeriodResult == "") || (response.GetWeeksforPayPeriodResult == undefined)){
                            hideLoadingIcon();
                            showAlert("Weekly Periods not found please try agin later.", "Timesheet");
                            }else{
                            $("#timeSheetPgWeeklyPeriod").empty("");
                            $("#timeSheetPgWeeklyPeriod").append("<option value='0'>Weekly Periods</option>");
                            for(i=0;i<response.GetWeeksforPayPeriodResult.length;i++){
                            
                            $("#timeSheetPgWeeklyPeriod").append("<option value="+response.GetWeeksforPayPeriodResult[i].Value+">"+response.GetWeeksforPayPeriodResult[i].Text+"</option>");
                            $("#timeSheetPgWeeklyPeriod").selectmenu().selectmenu("refresh");
                            
                            }
                            if(localStorage.getItem("weeklyPeriod") != ""){
                            $("#timeSheetPgWeeklyPeriod option[value="+localStorage.getItem('weeklyPeriod')+"]").prop("selected", "selected").change();
                            $("#timeSheetPgWeeklyPeriod").selectmenu().selectmenu("refresh");
                            }
                            }
                            hideLoadingIcon();
                            });
            }
                                      });



/*-- End Of Function --*/

/*-- Function to autofill the from and to date in search timesheet--*/

function timeSheetAutoFillFromToDateField(){

     Apploadingicon();
     weeklyPeriod = $("#timeSheetPgWeeklyPeriod :selected").text();
     weeklyPeriodSplit = weeklyPeriod.split("-");
     weeklyPeriod = weeklyPeriodSplit[2]+"-"+weeklyPeriodSplit[1]+"-"+weeklyPeriodSplit[0];
    
    
    now = new Date(weeklyPeriod);
    first = now.getDate() - now.getDay();
    first = new Date(now.setDate(first)).toUTCString();
    lastFullDate = new Date(first);
    
    lastFullDate.setDate(lastFullDate.getDate() + 7);
    day = lastFullDate.getDate();
    month = lastFullDate.getMonth() + 1;
    year = lastFullDate.getFullYear();
    
    if(day<10){
        day = "0"+day;
    }
    
    if(month<10){
        month = "0"+month;
    }
    
    lastFullDate = year+"-"+month+"-"+day;
    
    $("#timeSheetPgTo").val(lastFullDate);
    $("#timeSheetPgFrom").val(weeklyPeriod);
    hideLoadingIcon();
    
}

/*-- End Of Function --*/

/* Fuction to clear search filter fields */

function clearSearchFields(){
    
    $("#timeSheetPgFrom").val("");
    $("#timeSheetPgTo").val("");
    
}

/* End of function */

/*-- Timesheet Listview Function to fix parameter based on daily, weekly, monthly & fourtnightly--*/

function generateTimeSheetListView(type,frmPg){

    if(frmPg == "frmHomePg"){
        frm = 1;
    }else{
        frm = 0;
    }
    
    if(type=="filter"){
        
//        if(($("#timeSheetPgPayRollPeriod :selected").val() == 0) || ($("#timeSheetPgWeeklyPeriod :selected").val() == 0)){
//            showAlert("Please enter any of Filter By option to filter.", "Timesheet");
//        
//        }else
        
            if($("#timeSheetPgFrom").val() == ""){
            if($("#timeSheetPgFrom").is(":visible")){
                showAlert("Please enter From date.", "Timesheet");
            }else{
                console.log("no from to btn displayed to show");
            }
           
        }else if($("#timeSheetPgTo").val() == ""){
            
            if($("#timeSheetPgTo").is(":visible")){
                showAlert("Please enter To date.", "Timesheet");
            }else{
                console.log("no from to btn displayed to show");
            }
            
        }else{
            
            parameter = {
                    "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
                    "startDate":"" +$("#timeSheetPgFrom").val()+ "",
                    "endDate":"" +$("#timeSheetPgTo").val()+ ""
                }
            
            localStorage.setItem("searchFromDate",$("#timeSheetPgFrom").val());
            localStorage.setItem("searchToDate",$("#timeSheetPgTo").val());
            localStorage.setItem("payRollPeriod",$("#timeSheetPgPayRollPeriod option:selected").val());
            localStorage.setItem("weeklyPeriod",$("#timeSheetPgWeeklyPeriod option:selected").val());

            generatingTimesheetListView("filter");
            
        }
    }else if(type=="list"){
        
        timeSheetSavedFrom = "list";
        $("#timeSheetPgFrom").val("");
        $("#timeSheetPgTo").val("");
        $(".subHeaderLableLeftPadding").show();
        $(".timeSheetPgFrom").show();
        $(".timeSheetPgTo").show();
        
        parameter = { "employeeNum": localStorage.getItem("timeSheetEmployeeNumber") };
        
        generatingTimesheetListView("list");
        
    }else if(type=="daily"){
       
        /*code to find daily date*/
        /* Hide all filter for daily */
        
        $(".subHeaderLableLeftPadding").hide();
        
        timeSheetSavedFrom = "daily";
        now = new Date();
        day = now.getDate();
        month = now.getMonth()+1;
        year = now.getFullYear();
        
        if(day<10){
           day = "0"+day;
        }
        
        if(month<10){
            month = "0"+month;
        }
        
         firstFullDate = day+"-"+month+"-"+year;
         lastFullDate = day+"-"+month+"-"+year;
        
        parameter = {
            "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
            "startDate":"" +firstFullDate+ "",
            "endDate":"" +lastFullDate+ ""
        }
        generatingTimesheetListView("daily");
        
    }else if(type=="weekly"){
        
        /*Hide from and to filter alone*/
        
        $(".subHeaderLableLeftPadding").show();
        $(".timeSheetPgFrom").hide();
        $(".timeSheetPgTo").hide();

        /*code to find 1st and last day of the current week*/
        timeSheetSavedFrom = "weekly";
       
        parameter = {
            "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
            "startDate": localStorage.getItem("currentWeekFirstDate"),
            "endDate": localStorage.getItem("currentWeekLastDate")
        }
        generatingTimesheetListView("weekly");
        
    /*list to show  14 days before from current days*/
        
    }else if(type=="fourtnightly"){
        
        /*Show all filter*/
        
        $(".subHeaderLableLeftPadding").show();
        $(".timeSheetPgFrom").show();
        $(".timeSheetPgTo").show();
        
         /* Code to find last day of 14 days*/
        
        timeSheetSavedFrom = "fourtnightly";
        lastFullDate = new Date();
        
        day = lastFullDate.getDate();
        if(day<10){
            day = "0"+day;
        }
        
        month = lastFullDate.getMonth()+1;
        if(month<10){
            month = "0"+month;
        }
        
        year = lastFullDate.getFullYear();
        lastFullDate = day+"-"+month+"-"+year;
        
       /* Code to find first day of 14 days*/
        
        fortNightDays = new Date(+new Date - 12096e5);
        
        day = fortNightDays.getDate();
        if(day<10){
            day = "0"+day;
        }

        month = fortNightDays.getMonth()+1;
        if(month<10){
            month = "0"+month;
        }
        year = fortNightDays.getFullYear();
        
        firstFullDate = day+"-"+month+"-"+year;
        
        parameter = {
            "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
            "startDate":"" +firstFullDate+ "",
            "endDate":"" +lastFullDate+ ""
        }
        
        generatingTimesheetListView("fourtnightly");
        
    }else if(type=="monthly"){
        
        /*Show all filter*/
        
        $(".subHeaderLableLeftPadding").show();
        $(".timeSheetPgFrom").show();
        $(".timeSheetPgTo").show();
        
        timeSheetSavedFrom = "monthly";
        
        /* Code to find before 30 days*/
        
        now = new Date();
        firstFullDate = new Date(now.getFullYear(),now.getMonth(),1);
        lastFullDate =  new Date(now.getFullYear(),now.getMonth()+1,0);
        
        firstFullDate = firstFullDate.getDate()+"-"+(firstFullDate.getMonth()+1)+"-"+firstFullDate.getFullYear();
        lastFullDate = lastFullDate.getDate()+"-"+(lastFullDate.getMonth()+1)+"-"+lastFullDate.getFullYear();

        parameter = {
            "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
            "startDate":"" +firstFullDate+ "",
            "endDate":"" +lastFullDate+ ""
        }
        
        generatingTimesheetListView("monthly");
    }
}


/*-- Function to generate listview based on above parameter 
 Note: also list is diffrentiated based on submitted, approved, saved and rejected method  
 0 - saved
 1 - pending  which meanse submitted orange
 2 - confirm  approved green
 3 - rejected red  --*/

function generatingTimesheetListView(type){
    
    timeSheetWebService("POST", "GetTimesheetEntries", parameter, function(response) {
                        console.log("GetTimesheetEntries"+JSON.stringify(parameter));
//                        console.log("GetTimesheetEntries"+JSON.stringify(response));
                        if (response.GetTimesheetEntriesResult.length==0 || response.GetTimesheetEntriesResult.length==null) {
                       
                          hideLoadingIcon();
                        if(type=="filter"){
                        $("#timeSheetListview").empty();
                        showAlert("No Timesheet available.", "Timesheet");
                        }else{
                        $("#timeSheetListview").empty();
                        showAlert("No Timesheet available.", "Timesheet", function(){
                                  changePage("#timeSheetButtonPg","slide",true);
                                  });
                        }
                        }else{
                        $("#timeSheetListview").empty();
                        for(i=0;i<response.GetTimesheetEntriesResult.length;i++){
                        jobName = response.GetTimesheetEntriesResult[i].JobFullDescription;
                        taskName = response.GetTimesheetEntriesResult[i].JobTaskFullDescription;
                        units = response.GetTimesheetEntriesResult[i].Units;
                        lineNumber = response.GetTimesheetEntriesResult[i].LineNumber;
                        timeSheetStatus = response.GetTimesheetEntriesResult[i].TimesheetStatus;
                        if(response.GetTimesheetEntriesResult[i].plantEntryCount == 0){
                        noOfPlantEntry = "No Plant Entry";
                        }else{
                        noOfPlantEntry = response.GetTimesheetEntriesResult[i].plantEntryCount+" Plant Entry";
                        }
                        
                        /* Date Conversion */
                        
                        str = response.GetTimesheetEntriesResult[i].WorkDate;
                        str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                        now = new Date( +str );
                        day = ("0" + now.getDate()).slice(-2);
                        month = ("0" + (now.getMonth() + 1)).slice(-2);
                        year = now.getFullYear();
                        fullDate = "" +day+"/"+month+"/"+year+ "";
                        
                        simpleList = "<li data-icon='false' style='white-space:normal;'><div><div class='timeSheetListViewHeaderLeftPos' style='visibility:hidden !important;'>Nothing</div><div class='timeSheetListViewHeaderCenterPos'>"+noOfPlantEntry+"</div><div class='timeSheetListViewHeaderRightPos' id='truckIcon"+lineNumber+"'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-truck ui-btn-icon-notext infoIcon' onclick='timeSheetViewPlantEntry(\""+lineNumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+lineNumber+"\");'>Job: "+jobName+"<br>Task: "+taskName+"<br>Date: "+fullDate+"<br>Hours: "+units+"</div></li>";
                        
                        submittedList = "<li data-icon='false' style='white-space:normal;'><div><div class='timeSheetListViewHeaderLeftPos' style='color:darkorange;'>Submitted</div><div class='timeSheetListViewHeaderCenterPos'>"+noOfPlantEntry+"</div><div id='truckIcon"+lineNumber+"' class='timeSheetListViewHeaderRightPos'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-truck ui-btn-icon-notext infoIcon' onclick='timeSheetViewPlantEntry(\""+lineNumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+lineNumber+"\");'>Job: "+jobName+"<br>Task: "+taskName+"<br>Date: "+fullDate+"<br>Hours: "+units+"</div></li>";
                        
                        approvedList = "<li data-icon='false' style='white-space:normal;'><div><div class='timeSheetListViewHeaderLeftPos' style='color:green;'>Approved</div><div class='timeSheetListViewHeaderCenterPos'>"+noOfPlantEntry+"</div><div class='ui-nodisc-icon timeSheetListViewHeaderRightPos' id='truckIcon"+lineNumber+"'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-truck ui-btn-icon-notext infoIcon' onclick='timeSheetViewPlantEntry(\""+lineNumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+lineNumber+"\");'>Job: "+jobName+"<br>Task: "+taskName+"<br>Date: "+fullDate+"<br>Hours: "+units+"</div></li>";
                        
                        rejectedList = "<li data-icon='false' style='white-space:normal;'><div><div class='timeSheetListViewHeaderLeftPos' style='color:red;'>Rejected</div><div class='timeSheetListViewHeaderCenterPos'>"+noOfPlantEntry+"</div><div class='ui-nodisc-icon timeSheetListViewHeaderRightPos' id='truckIcon"+lineNumber+"'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-truck ui-btn-icon-notext infoIcon' onclick='timeSheetViewPlantEntry(\""+lineNumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+lineNumber+"\");'>Job: "+jobName+"<br>Task: "+taskName+"<br>Date: "+fullDate+"<br>Hours: "+units+"</div></li>";

                        if(timeSheetStatus == 0){
                        $("#timeSheetListview").append(simpleList);
                        }else if(timeSheetStatus == 1){
                        $("#timeSheetListview").append(submittedList);
                        }else if(timeSheetStatus == 2){
                        $("#timeSheetListview").append(approvedList);
                        }else if(timeSheetStatus == 3){
                        $("#timeSheetListview").append(rejectedList);
                        }
                        if(response.GetTimesheetEntriesResult[i].IsPlant){
                        console.log("Dont hide");
                        }else{
                        $("#truckIcon"+lineNumber).hide();
                        }
                        }
                        if(($("#timeSheetsTheme").val())=="template1"){
                        $(".infoIcon").css({"background-color":"#74203f","border-color":"#74203f"});
                        }else if(($("#timeSheetsTheme").val())=="default"){
                        $(".infoIcon").css({"background-color":"#375BAA","border-color":"#375BAA"});
                        }
                        hideLoadingIcon();
                        changePage("#timeSheetPg","slide",false);
                        }
                        if(frm){
                        localStorage.setItem("searchFromDate","");
                        localStorage.setItem("searchToDate","");
                        localStorage.setItem("payRollPeriod","");
                        localStorage.setItem("weeklyPeriod","");
                        frm = 0;
                        }
                        $("#timeSheetListview").listview("refresh");
                        });
                        generatingTimesheetListViewType = type;
    
    /* List Data by storing in local db
     
     changePage("#timeSheetPg","slide",false);
     db = window.sqlitePlugin.openDatabase({name: 'timeSheet.db', location: 'default'});
     console.log("db created successfully");
     db.transaction(function(tx) {
     tx.executeSql("DROP TABLE IF EXISTS timesheetDetails");
     tx.executeSql("CREATE TABLE IF NOT EXISTS timesheetDetails (id integer PRIMARY KEY, job TEXT, task VARCHAR(33), date STRING, hours NUMERIC, linenumber NUMERIC, timesheetstatus NUMERIC)",function(tx, res) {
     console.log("created");
     }, function(e) {
     console.log("ERROR: " + JSON.stringify(e));
     });
     for(i=0;i<response.GetTimesheetEntriesResult.length;i++){
     
     jobName = response.GetTimesheetEntriesResult[i]._jobFullDescription;
     taskName = response.GetTimesheetEntriesResult[i]._jobTaskFullDescription;
     units = response.GetTimesheetEntriesResult[i]._units;
     lineNumber = response.GetTimesheetEntriesResult[i]._lineNumber;
     var Date = response.GetTimesheetEntriesResult[i]._workDate;
     timeSheetStatus = response.GetTimesheetEntriesResult[i]._timesheetStatus;
     
     tx.executeSql("INSERT INTO timesheetDetails (job, task, date, hours, linenumber, timesheetstatus) VALUES (?,?,?,?,?,?)",[jobName, taskName, Date, units, lineNumber, timeSheetStatus],function(tx, res) {
     console.log("inserted");
     }, function(e) {
     console.log("ERROR: " + JSON.stringify(e));
     });
     }
     });
     
     db.transaction(function(tx) {
     $("#timeSheetListview").empty();
     for(var j=0;j<response.GetTimesheetEntriesResult.length;j++){
     
     tx.executeSql("select job,task,date,hours,linenumber,timesheetstatus from timesheetDetails where id="+j+";", [], function(tx, res) {
     str = res.rows.item(0).date;
     str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
     now = new Date(+str);
     day = ("0" + now.getDate()).slice(-2);
     month = ("0" + (now.getMonth() + 1)).slice(-2);
     year = now.getFullYear();
     fullDate = "" +day+"/"+month+"/"+year+ "";
     if(res.rows.item(0).timesheetstatus == 0){
     $("#timeSheetListview").append("<li data-icon='false'><div><div class='timeSheetListViewHeaderLeftPos'><img src='img/orangedot.png' class='timeSheetListViewHeaderLeftPosImg'/></div><div class='timeSheetListViewHeaderCenterPos'></div><div class='ui-nodisc-icon timeSheetListViewHeaderRightPos'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-info ui-btn-icon-notext ui-btn-b' onclick='timeSheetViewPlantEntry(\""+res.rows.item.linenumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+res.rows.item(0).linenumber+"\");'>Job: "+res.rows.item(0).job+"<br>Task:  "+res.rows.item(0).task+"<br>Date: "+fullDate+"<br>Hours:"+res.rows.item(0).hours+"</div></li>");
     }else if(res.rows.item(0).timesheetstatus == 1){
     $("#timeSheetListview").append("<li data-icon='false'><div><div class='timeSheetListViewHeaderLeftPos'><img src='img/greendot.png' style='height:13px;width:13px;'/></div><div class='timeSheetListViewHeaderCenterPos'></div><div class='ui-nodisc-icon timeSheetListViewHeaderRightPos'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-info ui-btn-icon-notext ui-btn-b' onclick='timeSheetViewPlantEntry(\""+res.rows.item.linenumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+res.rows.item(0).linenumber+"\");'>Job: "+res.rows.item(0).job+"<br>Task:  "+res.rows.item(0).task+"<br>Date: "+fullDate+"<br>Hours:"+res.rows.item(0).hours+"</div></li>");
     }else if(res.rows.item(0).timesheetstatus == 2){
     $("#timeSheetListview").append("<li data-icon='false'><div><div class='timeSheetListViewHeaderLeftPos'><img src='img/reddot.png' style='height:13px;width:13px;'/></div><div class='timeSheetListViewHeaderCenterPos'></div><div class='ui-nodisc-icon timeSheetListViewHeaderRightPos'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-info ui-btn-icon-notext ui-btn-b' onclick='timeSheetViewPlantEntry(\""+res.rows.item.linenumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+res.rows.item(0).linenumber+"\");'>Job: "+res.rows.item(0).job+"<br>Task:  "+res.rows.item(0).task+"<br>Date: "+fullDate+"<br>Hours:"+res.rows.item(0).hours+"</div></li>");
     }
     
     $("#timeSheetListview").listview("refresh");
     hideLoadingIcon();
     });
     }
     //db.close();
     //    db.close(successcb, errorcb);
     hideLoadingIcon();
     }, function(error) {
     console.log('transaction error: ' + error.message);
     //                                       db.close();
     });
     }
     }); */
    
}


/*-- End Of Timesheet Listview Function --*/


/* Function when checkbox clicked popup opens */

$("#timeSheetPlantEntry").click(function(){
                        
/* if loop to check and apply theme for delete icon in popup, as color does not applied directly*/
                                
        if(($("#timeSheetsTheme").val())=="template1"){
                                
          popUpDeleteIcon = "<a href='#' class='ui-btn ui-shadow ui-corner-all ui-icon-delete ui-btn-icon-notext ui-btn-inline ui-nodisc-icon plantEntryDeleteIcon' style='background-color:#74203f;color:#ffffff;text-shadow:none;border-color:#74203f;'>Delete</a>" ;
                                
        }else if(($("#timeSheetsTheme").val())=="default"){
                                
          popUpDeleteIcon = "<a href='#' class='ui-btn ui-shadow ui-corner-all ui-icon-delete ui-btn-icon-notext ui-btn-inline ui-nodisc-icon plantEntryDeleteIcon' style='background-color:#375BAA;color:#ffffff;text-shadow:none;border-color:#375BAA;'>Delete</a>";
                              
        }
                                
        if($("#timeSheetPlantEntry").prop("checked")==true){
                                
        /* Loading plant no details*/
                                
        timeSheetWebService("POST", "GetPlantNumber", "", function(response) {
        //console.log("PlantNumber"+JSON.stringify(response));
                            if((response.GetPlantNumberResult.length == 0) || (response.GetPlantNumberResult.length == null) || (response.GetPlantNumberResult.length == undefined)){
                            showAlert("Couldn't able to fetch plant number, please try again later.","Timesheet");
                            }else{
                            $("#plantno").empty();
                            for(i=0;i<response.GetPlantNumberResult.length;i++){
                            $("#plantno").append("<option value="+i+">"+response.GetPlantNumberResult[i].No_+"</option>");
                            }
                            
        /* Loading work type code details*/
                            
        timeSheetWebService("POST", "GetWorkTypeCode", "", function(response) {
        //console.log("GetWorkTypeCode"+JSON.stringify(response));
                           if((response.GetWorkTypeCodeResult == null)||(response.GetWorkTypeCodeResult == undefined)||(response.GetWorkTypeCodeResult.length == 0)){
                            hideLoadingIcon();
                            showAlert("Couldn't able to fetch work type code please try again.","Timesheet");
                            }else{
                            $("#wrkTypeCode").empty();
                            for(i=0;i<response.GetWorkTypeCodeResult.length;i++){
                            $("#wrkTypeCode").append("<option value="+response.GetWorkTypeCodeResult[i].CustomerNo+">"+response.GetWorkTypeCodeResult[i].Code+"</option>");
                            }
                            $("#plantno").selectmenu("refresh", true);
                            $("#wrkTypeCode").selectmenu("refresh", true);
                            getPlantEntries();
                            }
                            });
                            }
        });
                            
         }else{
            //console.log("unchecked");
            $("#timeSheetPlantEntry").prop("checked",false).checkboxradio("refresh");
            $("#timeSheetPlantEntryDialogTableContent").empty();
            $("#timeSheetPlantEntryDialog").popup("close");
         }
         });

/* Function to close Plant entry popup  */

function closePopUpPlantEntry(){
    $("#timeSheetPlantEntryDialog").popup("option","history",false);
    $("#timeSheetPlantEntryDialogTableContent").empty();
    $("#timeSheetPlantEntryDialog").popup("close");
    $("#timeSheetPlantEntry").prop("checked",false).checkboxradio("refresh");
}

/* End of function  */

/* Function to get plant entries */

function getPlantEntries(){
    
    //open dialog
    
    parameter = {
        "linenumber": localStorage.getItem("timeSheetListLineNumber")
    }
    
    if(localStorage.getItem("timeSheetListLineNumber") == ""){
        hideLoadingIcon();
        showAlert("Please save timesheet to add/view plant entry.","Timesheet");
        $("#timeSheetPlantEntry").prop("checked", false).checkboxradio("refresh");
        
    }else{
    timeSheetWebService("POST", "GetPlantEntries", parameter, function(response) {
                        console.log("result" + JSON.stringify(response));
                        if((response.GetPlantEntriesResult == null) || (response.GetPlantEntriesResult == undefined) || (response.GetPlantEntriesResult.length == 0)){
                        $("#timeSheetPlantEntryDialogTableContent").empty();
                        $("#timeSheetPlantEntryDialogTableContent").append("<p class='noPlantEntryContent'>No Plant Entries Available!<p>");
                        $("#timeSheetPlantEntryUnits").val("");
                        $("#timeSheetPlantEntryDialog").popup("open");
                        hideLoadingIcon();
                        }else{
                        $("#timeSheetPlantEntryDialogTableContent").empty();
                        for (i=0;i<response.GetPlantEntriesResult.length;i++){
                        $("#timeSheetPlantEntryDialogTableContent").append("<tr>\
                                                                           <td align='center'>"+response.GetPlantEntriesResult[i].ResourceNo+"</td>\
                                                                           <td align='center'>"+response.GetPlantEntriesResult[i].WorkTypeCode+"</td>\
                                                                           <td align='center'>"+response.GetPlantEntriesResult[i].Units+"</td>\
                                                                           <td id="+response.GetPlantEntriesResult[i].EntryNo+" onclick='timeSheetDeletePlantEntry("+response.GetPlantEntriesResult[i].EntryNo+")'>"+popUpDeleteIcon+"</td></tr>");
                        }
                        $("#timeSheetPlantEntryUnits").val("");
                        $("#timeSheetPlantEntryDialog").popup("open");
                        hideLoadingIcon();
                        }
                        });
    }
}

/*-- End Of Plant Entry Function --*/


/* Saving timesheet plant entry function  */

function timeSheetSavePlantEntry(){
   
    now = new Date();
    day = now.getDate();
    month = now.getMonth();
    month = month+1;
    year = now.getFullYear();
    
    if(day<10){
        day = "0"+day;
    }
    
    if(month<10){
        month = "0"+month;
    }

    currentDate = month+"-"+day+"-"+year;
    
    if((localStorage.getItem("timeSheetListLineNumber")== "") || (localStorage.getItem("timeSheetListLineNumber")== null) || (localStorage.getItem("timeSheetListLineNumber")== undefined)){
        
        hideLoadingIcon();
        showAlert("Please save timesheet to make a plant entry.", "Timesheet", function(){
                  $("#timeSheetPlantEntry").prop("checked", false).checkboxradio("refresh");
                  $("#timeSheetPlantEntryUnits").val("");
                  $("#timeSheetPlantEntryDialog").popup("close");
                  });

    }else{
        
        if($("#timeSheetPlantEntryUnits").val() == ""){
            showAlert("Please enter Units.","Timesheet");
        }else if($("#timeSheetPlantEntryUnits").val() == 0){
            showAlert("Please enter valid Units.","Timesheet");
        }else if($("#timeSheetPlantEntryUnits").val()>24){
            showAlert("Please enter Hours less than 24 Hrs.", "Timesheet", function(){
                      $("#timeSheetPlantEntryUnits").focus();
                      });
        }else if((($("#timeSheetPlantEntryUnits").val().indexOf('.'))!= -1)&&(($("#timeSheetPlantEntryUnits").val().substring($("#timeSheetPlantEntryUnits").val().indexOf('.'), $("#timeSheetPlantEntryUnits").val().indexOf('.').length).length)>3)){
                showAlert("Please enter less than 2 decimal values.", "Timesheet", function(){
                          $("#timeSheetPlantEntryUnits").focus();
                          });
        }else{
        
    parameter =
            
        {"entry":{
            "ResourceNo": $("#plantno option:selected").text(),
            "WorkTypeCode":$("#wrkTypeCode option:selected").text(),
            "Units":$("#timeSheetPlantEntryUnits").val(),
            "EmployeeNo":localStorage.getItem("timeSheetEmployeeNumber"),
            "PayrollNo":localStorage.getItem("timeSheetPayRollNumber"),
            "WorkDate":currentDate,
            "PayJournalLineNo":localStorage.getItem("timeSheetListLineNumber")
        }
        }
    
    console.log(JSON.stringify(parameter));
    timeSheetWebService("POST", "SaveUpdatePlantEntry", parameter, function(response) {
                        console.log("SaveUpdatePlantEntry"+JSON.stringify(response));
                        if(response.SaveUpdatePlantEntryResult) {
                                  $("#timeSheetPlantEntryUnits").val("");
                                  getPlantEntries();
                        }else{
                        hideLoadingIcon();
                        showAlert("Unable to add plant entry for the timesheet.", "Timesheet");
                        }
                        });
        
    }
    }

}

/*-- End Of save Plant Entry Function --*/

/*-- Delete plant entry Function --*/

function timeSheetDeletePlantEntry(no){
    
    plantEntryNo = no;
    promptAlert("Are you sure you want to delete this Plant Entry?", deletePlantEntryConfirm, "Timesheet", "Yes", "No");
    
}

function deletePlantEntryConfirm(index){

    if(index == 1){
       parameter = {
            "entryNo":plantEntryNo
        }
        console.log("parameter"+JSON.stringify(parameter));
        timeSheetWebService("POST", "DeletePlantEntry", parameter, function(response) {
                            console.log("DeletePlantEntryResult"+JSON.stringify(response));
                            if(response.DeletePlantEntryResult){
                            $("#timeSheetPlantEntryDialogTableContent").empty();
                                      $("#timeSheetPlantEntryUnits").val("");
                                      getPlantEntries();
                            hideLoadingIcon();
                            }else{
                            hideLoadingIcon();
                            showAlert("Could'nt able to delete plant entry.", "Timesheet");
                            }
                            });
    }else{
        console.log("do nothing");
    }

}

/*-- End Of Delete Plant Entry Function --*/


/* View timesheet popup for plant entry */

function timeSheetViewPlantEntry(linenumber)

{
    parameter = {
        "linenumber": linenumber
    }
    
    timeSheetWebService("POST", "GetPlantEntries", parameter, function(response) {
                        console.log("GetPlantEntries" + JSON.stringify(response));
                        if((response.GetPlantEntriesResult == null) || (response.GetPlantEntriesResult == undefined) || (response.GetPlantEntriesResult.length == 0)){
                        showAlert("Unable to view plant entry.","Timesheet");
                        hideLoadingIcon();
                        }else{
                        $("#timeSheetViewPlantEntryPopupContent").empty();
                        for (i=0;i<response.GetPlantEntriesResult.length;i++){
                        $("#timeSheetViewPlantEntryPopupContent").append("<tr>\
                                                                           <td align='center'>"+response.GetPlantEntriesResult[i].ResourceNo+"</td>\
                                                                           <td align='center'>"+response.GetPlantEntriesResult[i].WorkTypeCode+"</td>\
                                                                           <td align='center'>"+response.GetPlantEntriesResult[i].Units+"</td></tr>");
                        }
                        $("#timeSheetViewPlantEntryPopup").popup("open");
                        hideLoadingIcon();
                        }
                        });
    
}

/*End of View timesheet popup for plant entry*/


function closeViewPopUpPlantEntry(){
    $("#timeSheetViewPlantEntryPopup").popup("close");
}

/* End of function */

/* Function to generate timesheet list when moved back from add timesheet page */

function timeSheetPreviousPage(){
    if(fromPg == "timeSheetButtonPg"){
        changePage("#timeSheetButtonPg","slide",true);
    }else if(fromPg == "timeSheetPg"){
        
        if(($("#timeSheetListview li").length)==0){
            showAlert("No Timesheet available.","Timesheet");
        }else{
        generateTimeSheetListView(generatingTimesheetListViewType);
        }
        //console.log(generatingTimesheetListViewType);
        fromViewPg = 0;
        changePage("#timeSheetPg","slide",true);
    }
}

/* End of function */

/* Function to generate timesheet select box values */

function generateTimeSheetSelectboxValues(page){

    //  selectbox Hours Type Values
    /*--inorder to make back button work from addnew this if condition is included--*/
    
    if(page == "addPg"){
        console.log("no op");
    }else{
    fromPg = $.mobile.activePage.attr("id");
    }
    
    $("#timeSheetSaveIcon").removeClass("ui-disabled");
    $("#timeSheetSaveAndNewIcon").removeClass("ui-disabled");
    $("#timeSheetSubmittedIcon").addClass("ui-disabled");
    $("#timeSheetDeleteIcon").addClass("ui-disabled");
    $("#addTimeSheetPgHoursType").val("");
    $("#addTimeSheetPgJob").val("");
    $("#addTimeSheetPgTask").val("");
    $("#addTimeSheetPgDate").val("");
    $("#timeSheetPlantEntry").prop("checked", false);
    $("#addTimeSheetPgHours").val("");
    $("#addTimeSheetPgComments").val("");
    $(".addTimeSheetPgManagerComments").hide();
    $(".ui-input-clear").addClass("ui-nodisc-icon");
    
    hoursTypeListArray = [];
    jobListArray = [];
    taskListArray = [];
    taskListArrayAutoComplete = [];
    
    parameter = "";
    
    /*  Selectbox Hours Type value */
    
    timeSheetWebService("POST", "GetPayTransactionTypes", parameter, function(response) {
                        //console.log("GetPayTransactionTypes"+JSON.stringify(response));
                        hoursTypeListArray = [];
                        if (response.GetPayTransactionTypesResult.length!=0 ||response.GetPayTransactionTypesResult.length!=null) {
                        for(i=0;i<response.GetPayTransactionTypesResult.length;i++){
                        hoursTypeListArray[i] = {"value":response.GetPayTransactionTypesResult[i].Value,"data":response.GetPayTransactionTypesResult[i].Name};
                        }
                        hideLoadingIcon();
                        } else {
                        hideLoadingIcon();
                        showAlert("Cannot able to fetch Hours Type.", "Timesheet");
                        }
                        
                        });

    
    /*  Selectbox Job value */
    
    timeSheetWebService("POST", "GetJobsList", parameter, function(response) {
                        //console.log("GetJobsList"+JSON.stringify(response));
                        jobListArray = [];
                        if (response.GetJobsListResult.length!=0 ||response.GetJobsListResult.length!=null) {
                        for(i=0;i<response.GetJobsListResult.length;i++){
                        jobListArray[i] = {"value":response.GetJobsListResult[i].Value,"data":response.GetJobsListResult[i].Name};
                        }
                        hideLoadingIcon();
                        } else {
                        hideLoadingIcon();
                        showAlert("Cannot able to fetch Job.", "Timesheet");
                        }
                        
                        });
    
    
    /*  Selectbox Task Value */
    
    timeSheetWebService("POST", "GetJobTaskList", parameter, function(response) {
                        //console.log("GetJobTaskList"+JSON.stringify(response));
                        taskListArray = [];
                        if (response.GetJobTaskListResult.length!=0 ||response.GetJobTaskListResult.length!=null) {
                        for(i=0;i<response.GetJobTaskListResult.length;i++){
                        taskListArray[i] = {"JobNumber":response.GetJobTaskListResult[i].JobNumber,"Name":response.GetJobTaskListResult[i].Name,"Value":response.GetJobTaskListResult[i].Value};
                        }
                        changePage("#addTimeSheetPg","slide");
                        hideLoadingIcon();
                        } else {
                        hideLoadingIcon();
                        showAlert("Cannot able to fetch Task.", "Timesheet");
                        }
                        });
    
}
  
/*-- Function will be called when focus made on hourstype field and autofocus result will be generated --*/

$("#addTimeSheetPgHoursType").focus(function(){
$("#addTimeSheetPgHoursType").autocomplete({
                                           lookup: hoursTypeListArray,
                                           minChars: 0,
                                           showNoSuggestionNotice: true,
                                           noSuggestionNotice: "No Match Found"
                                           });
                                    });



/*-- Function will be called when focus made on joblist field and autofocus result will be generated --*/

$("#addTimeSheetPgJob").focus(function(){
$("#addTimeSheetPgJob").autocomplete({
                                     lookup: jobListArray,
                                     minChars: 0,
                                     showNoSuggestionNotice: true,
                                     noSuggestionNotice: "No Match Found",
                                     onInvalidateSelection:onJobChange(),
                                     onSelect: function (suggestion) {
                                     addTimeSheetPgJobChange(suggestion.data);
                                     }
                                     });
                                     });

/*-- Function will be everytime when change made on job field to enter "NO TASK SELECTED" text in task field  --*/

function onJobChange(){
   
    $("#addTimeSheetPgTask").val("NO TASK SELECTED");
}

/*-- Function to fill task data in array where this tasks is based on job selected in job field--*/

function addTimeSheetPgJobChange(jobno) {
    
                                Apploadingicon();
                                taskListArrayAutoComplete = [];
                                j=0;
                               for(i=0;i<taskListArray.length;i++){
                               if(jobno == taskListArray[i].JobNumber){
    taskListArrayAutoComplete[j] = {"value":taskListArray[i].Name+" - "+taskListArray[i].Value,"data":taskListArray[i].Name};
                                   j++;
                               }
                               }
                               hideLoadingIcon();
    
                      }

/*-- Function will be called when focus made on tasklist field and autofocus result will be generated --*/

$("#addTimeSheetPgTask").focus(function(){
$("#addTimeSheetPgTask").autocomplete({
                                      lookup: taskListArrayAutoComplete,
                                      minChars: 0,
                                      showNoSuggestionNotice: true,
                                      noSuggestionNotice: "No Match Found",
                                      onInvalidateSelection:onTaskChange(),
                                      });
                                  });

/*-- Function will be called whenever changes made on task field --*/

function onTaskChange(){
    $("addTimeSheetPgJob").val("NO JOB SELECTED");
}

/* End of function */

/*-- View Timesheet Function --*/

function viewTimeSheetDetails(lineno){
    
    fromViewPg = 1;
    localStorage.setItem("timeSheetListLineNumber",lineno);
    generateTimeSheetSelectboxValues();
    
    parameter = {
    "lineNumber":lineno
    }

    timeSheetWebService("POST", "GetTimesheetEntry", parameter, function(response) {
                        //console.log("GetTimesheetEntry"+JSON.stringify(response));
                        if (response.GetTimesheetEntryResult.Status) {
                        /*timesheet status 2 which means that particular timesheet have been submitted already*/
                        if(response.GetTimesheetEntryResult.TimesheetStatus == 1 || response.GetTimesheetEntryResult.TimesheetStatus == 2 || response.GetTimesheetEntryResult.TimesheetStatus == 3){
                        $("#timeSheetSaveIcon").addClass("ui-disabled");
                        $("#timeSheetSaveAndNewIcon").addClass("ui-disabled");
                        $("#timeSheetSubmittedIcon").addClass("ui-disabled");
                        $("#timeSheetPlantEntryDiv").hide();
                        }else{
                        $("#timeSheetSaveIcon").removeClass("ui-disabled");
                        $("#timeSheetSaveAndNewIcon").removeClass("ui-disabled");
                        $("#timeSheetSubmittedIcon").removeClass("ui-disabled");
                        $("#timeSheetDeleteIcon").removeClass("ui-disabled");
                        $("#timeSheetPlantEntryDiv").show();
                        }
                        if(response.GetTimesheetEntryResult.TimesheetStatus == 1 || response.GetTimesheetEntryResult.TimesheetStatus == 2){
                        $("#timeSheetDeleteIcon").addClass("ui-disabled");
                        }
                        
                        if(response.GetTimesheetEntryResult.TimesheetStatus == 3){
                        $(".addTimeSheetPgManagerComments").show();
                        }else{
                        $(".addTimeSheetPgManagerComments").hide();
                        }
                        
                        str = response.GetTimesheetEntryResult.WorkDate;
                        str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                        now = new Date(+str);
                        day = ("0" + now.getDate()).slice(-2);
                        month = ("0" + (now.getMonth() + 1)).slice(-2);
                        fullDate = now.getFullYear()+"-"+month+"-"+day;
                        
                        $("#addTimeSheetPgDate").val(fullDate);
                        $("#addTimeSheetPgHoursType").val(response.GetTimesheetEntryResult.TransactionType);
                        $("#addTimeSheetPgJob").val(response.GetTimesheetEntryResult.JobFullDescription);
                        $("#addTimeSheetPgHours").val(response.GetTimesheetEntryResult.Units);
                        $("#addTimeSheetPgComments").val(response.GetTimesheetEntryResult.EmployeeComments);
                        $("#addTimeSheetPgManagerComments").val(response.GetTimesheetEntryResult.ManagerComments);
                        
                        for(i=0;i<jobListArray.length;i++){
                        if((jobListArray[i].value) == ($("#addTimeSheetPgJob").val())){
                        jobno = jobListArray[i].data;
                        }
                        }
                            taskListArrayAutoComplete = [];
                            j=0;
                            for(i=0;i<taskListArray.length;i++){
                                if(jobno == taskListArray[i].JobNumber){
                                    taskListArrayAutoComplete[j] = {"value":taskListArray[i].Name+" - "+taskListArray[i].Value,"data":taskListArray[i].Name};
                                    j++;
                                }
                            }

                        $("#addTimeSheetPgTask").val(response.GetTimesheetEntryResult.JobTaskFullDescription);
                        //localStorage.setItem("TaskFieldNumber",response.GetTimesheetEntryResult.JobTaskNumber);
                        hideLoadingIcon();
                        changePage("#addTimeSheetPg","slide");
                        } else {
                        hideLoadingIcon();
                        showAlert("Unable to view timesheet details please try again.", "Timesheet");
                        }
                        });
    
}

/*-- End Of View Timesheet Function --*/

/*-- Save, Save&New, Submit Timesheet Listview Function --*/

function timeSheetSaveNew(type){
    
    now = new Date($("#addTimeSheetPgDate").val());
    day = now.getDate();
    if (day<10){
        day = "0"+day;
    }
    month = now.getMonth()+1;
    if(month<10){
        month = "0"+month;
    }
    year = now.getFullYear();
    fullDate = day+"-"+month+"-"+year;
    
    if($("#addTimeSheetPgDate").val() == "") {
        showAlert("Please enter Date.", "Timesheet", function(){
                  $("#addTimeSheetPgDate").focus();
                  });
    }else if($("#addTimeSheetPgHoursType").val()==""){
        showAlert("Please enter Hours Type.", "Timesheet", function(){
                  $("#addTimeSheetPgHoursType").focus();
                  });
    }else if($("#addTimeSheetPgHours").val()==""){
        showAlert("Please enter Hours.", "Timesheet", function(){
                  $("#addTimeSheetPgHours").focus();
                  });
    }else if($("#addTimeSheetPgHours").val()==0){
        showAlert("Please enter valid Hours.", "Timesheet", function(){
                  $("#addTimeSheetPgHours").focus();
                  });
    }else if($("#addTimeSheetPgHours").val()>24){
        showAlert("Please enter Hours less than 24 Hrs.", "Timesheet", function(){
                  $("#addTimeSheetPgHours").focus();
                  });
    }else if((($("#addTimeSheetPgHours").val().indexOf('.'))!= -1)&&(($("#addTimeSheetPgHours").val().substring($("#addTimeSheetPgHours").val().indexOf('.'), $("#addTimeSheetPgHours").val().indexOf('.').length).length)>3)){
             showAlert("Please enter less than 2 decimal values.", "Timesheet", function(){
                       $("#addTimeSheetPgHours").focus();
                       });
 
    }else{
    
        for(i=0;i<hoursTypeListArray.length;i++){
            if(hoursTypeListArray[i].value == $("#addTimeSheetPgHoursType").val()){
               hoursTypeTextFieldValue  = hoursTypeListArray[i].data;
            }
        }
        
        for(i=0;i<jobListArray.length;i++){
            if(jobListArray[i].value == $("#addTimeSheetPgJob").val()){
                jobListTextFieldValue = jobListArray[i].data;
            }
        }
        
        if((jobListTextFieldValue == null) || (jobListTextFieldValue == "") || (jobListTextFieldValue == undefined)){
           
                jobListTextFieldValue = "NO JOB SELECTED";
        }
        
        if((hoursTypeTextFieldValue == null) || (hoursTypeTextFieldValue == "") || (hoursTypeTextFieldValue == undefined)){
            
            hoursTypeTextFieldValue = "";
        }
        
        if(jobListTextFieldValue == "NO JOB SELECTED"){
            
            taskListTextFieldValue = "NO TASK SELECTED";
            
        }else{
            
        for(i=0;i<taskListArrayAutoComplete.length;i++){
            
            if(($("#addTimeSheetPgTask").val() == "") || ($("#addTimeSheetPgTask").val() == "NO TASK SELECTED")){
                
                taskListTextFieldValue = "NO TASK SELECTED";
                
            }else if(taskListArrayAutoComplete[i].value == $("#addTimeSheetPgTask").val()){
                
                    taskListTextFieldValue = taskListArrayAutoComplete[i].data;
            }
        }
        }
        
    if((type=="saveandnew") || (type=="save")){
        
        console.log("fromViewPg"+fromViewPg);
        if(fromViewPg==1){
            
            if(localStorage.getItem("timeSheetListLineNumber")==""){
                localStorage.setItem("timeSheetListLineNumber","-1")
            }
            
            parameter =
            {"entry":
                {
                    "lineNo":localStorage.getItem("timeSheetListLineNumber"),
                    "JobId": jobListTextFieldValue,
                    "TaskId": taskListTextFieldValue,
                    "EntryDate":fullDate,
                    "Hours":$("#addTimeSheetPgHours").val(),
                    "TransactionType":hoursTypeTextFieldValue,
                    "Comments":$("#addTimeSheetPgComments").val(),
                    "Status":"0",
                    "EmployeeNo":localStorage.getItem("timeSheetEmployeeNumber")
                }
            }
        }else{
            
        parameter =
            
        {"entry":
            {
                "lineNo":"-1",
                "JobId":jobListTextFieldValue,
                "TaskId":taskListTextFieldValue,
                "EntryDate":fullDate,
                "Hours":$("#addTimeSheetPgHours").val(),
                "TransactionType":hoursTypeTextFieldValue,
                "Comments":$("#addTimeSheetPgComments").val(),
                "Status":"0",
                "EmployeeNo":localStorage.getItem("timeSheetEmployeeNumber")
            }
        }
          fromViewPg = 1;
        }
        
        console.log("Parameter"+JSON.stringify(parameter));
        if(hoursTypeTextFieldValue == null || hoursTypeTextFieldValue == "" || hoursTypeTextFieldValue == undefined){
            $("#addTimeSheetPgHoursType").val("");
            $("#addTimeSheetPgHoursType").focus();
            hideLoadingIcon();
            showAlert("Please enter correct hours type.","Timesheet");
        }else{
            
        timeSheetWebService("POST", "SaveUpdateTimesheetEntry", parameter, function(response) {
                            //console.log("SaveTimesheetEntry"+JSON.stringify(parameter));
                            //console.log("SaveTimesheetEntry"+JSON.stringify(response));
                            if(response.SaveUpdateTimesheetEntryResult.Status) {
                            hideLoadingIcon();
                            showAlert("Timesheet added/updated successfully.", "Timesheet", function(){
                                      hoursTypeTextFieldValue = "";
                                      jobListTextFieldValue = "";
                                      taskListTextFieldValue = "";
                                      if(type=="saveandnew"){
                                      generateTimeSheetSelectboxValues('addPg');
                                      $("#addTimeSheetPgDate").val();
                                      $("#addTimeSheetPgHours").val();
                                      $("#addTimeSheetPgComments").val();
                                      $("#addTimeSheetPgHoursType").val("");
                                      $("#addTimeSheetPgJob").val("");
                                      $("#addTimeSheetPgTask").val("");
                                      $("#timeSheetSubmittedIcon").addClass("ui-disabled");
                                      $("#timeSheetDeleteIcon").addClass("ui-disabled");
                                      localStorage.setItem("timeSheetListLineNumber","");
                                      }else{
                                      localStorage.setItem("timeSheetListLineNumber",response.SaveUpdateTimesheetEntryResult.Number);
                                      $("#timeSheetSubmittedIcon").removeClass("ui-disabled");
                                      $("#timeSheetDeleteIcon").removeClass("ui-disabled");
                                      }
                                      });
                            } else {
                            hideLoadingIcon();
                            showAlert("Unable to add timesheet please try again.", "Timesheet");
                            }
                            });
        }
        
    }else if(type=="submit"){
       
        now = new Date();
        day = now.getDate();
        if (day<10){
            day = "0"+day;
        }
        month = now.getMonth()+1;
        if(month<10){
            month = "0"+month;
        }
        year = now.getFullYear();
        submitFullDate = day+"-"+month+"-"+year;
        
        multiplePromptAlert("Timesheet submission period based on?", timeSheetSubmission, "Timesheet", "Current", "Weekly", "Cancel");
        
    }else if(type=="delete"){
        parameter = {
            "lineNum":localStorage.getItem("timeSheetListLineNumber")
        }
        
        promptAlert("Are you sure you want to delete this Timesheet?", deleteTimeSheet, "Timesheet", "Yes", "No");
    }
}
}

/*-- End Of Save, Save&New Timesheet Listview Function --*/

/* Function to submit timesheet*/

function timeSheetSubmission(index){
 
    /*-- Individual timesheet submission --*/
    if(index==1){
        
        parameter =
        {   "employeeNumber":localStorage.getItem("timeSheetEmployeeNumber"),
            "submittedDate":submitFullDate,
            "startDate":fullDate,
            "endDate":fullDate,
            "lineNumber":localStorage.getItem("timeSheetListLineNumber")
        }
        
        timeSheetWebService("POST", "SubmitEmployeeTimesheetByWeek", parameter, function(response) {
                            console.log("SubmitEmployeeTimesheetByWeek"+JSON.stringify(response));
                            if(response.SubmitEmployeeTimesheetByWeekResult){
                            parameter = {
                            "employee":{
                            "EmployeeNo":localStorage.getItem("timeSheetEmployeeNumber"),
                            "Password":localStorage.getItem("timeSheetPassword"),
                            "frmDate":localStorage.getItem("currentWeekFirstDate"),
                            "toDate":localStorage.getItem("currentWeekLastDate")
                            }
                            }
                            timeSheetWebService("POST", "GetEmployee", parameter, function(response) {
                                                //console.log("GetEmployee"+JSON.stringify(response));
                                                if (response.GetEmployeeResult.Status) {
                                                empWorkedHours = response.GetEmployeeResult.TotalUnits;
                                                /*-- To generate list after submission base on daily,weekly,fourtnightly & monthly or all --*/
                                                showAlert("Timesheet submitted successfully.", "Timesheet", function(){
                                                          getEmpDetails();
                                                          if(fromPg == "timeSheetButtonPg"){
                                                          changePage("#timeSheetButtonPg","slide",true);
                                                          hideLoadingIcon();
                                                          }else{
                                                          if(timeSheetSavedFrom=="daily"){
                                                          generateTimeSheetListView('daily');
                                                          }else if(timeSheetSavedFrom=="weekly"){
                                                          generateTimeSheetListView('weekly');
                                                          }else if(timeSheetSavedFrom=="fourtnightly"){
                                                          generateTimeSheetListView('fourtnightly');
                                                          }else if(timeSheetSavedFrom=="monthly"){
                                                          generateTimeSheetListView('monthly');
                                                          }else{
                                                          generateTimeSheetListView('list');
                                                          }
                                                          }
                                                          fromViewPg = 0;
                                                          //timeSheetSavedFrom = "";
                                                          });

                                                }
                                                });
//                          empWorkedHours = response.empworkedhours;
                            }else{
                            showAlert("Unable to submit timesheet please try again.", "Timesheet");
                            hideLoadingIcon();
                            }
                            });
      /*-- Weekly timesheet submission --*/
    }else if(index==2){
       
        parameter =
        {   "employeeNumber":localStorage.getItem("timeSheetEmployeeNumber"),
            "submittedDate":submitFullDate,
            "startDate":localStorage.getItem("currentWeekFirstDate"),
            "endDate":localStorage.getItem("currentWeekLastDate"),
            "lineNumber":"0"
        }

        timeSheetWebService("POST", "SubmitEmployeeTimesheetByWeek", parameter, function(response) {
                            //console.log("SubmitEmployeeTimesheetByWeek"+JSON.stringify(response));
                            if(response.SubmitEmployeeTimesheetByWeekResult){
                            parameter = {
                            "employee":{
                            "EmployeeNo":localStorage.getItem("timeSheetEmployeeNumber"),
                            "Password":localStorage.getItem("timeSheetPassword"),
                            "frmDate":localStorage.getItem("currentWeekFirstDate"),
                            "toDate":localStorage.getItem("currentWeekLastDate")
                            }
                            }
                            
                            timeSheetWebService("POST", "GetEmployee", parameter, function(response) {
                                                if (response.GetEmployeeResult.Status) {
                                                empWorkedHours = response.GetEmployeeResult.TotalUnits;
                                                }
                                                });
                            
                            hideLoadingIcon();
                            showAlert("Timesheet submitted successfully.", "Timesheet", function(){
                                      getEmpDetails();
                                      if(timeSheetSavedFrom=="daily"){
                                      generateTimeSheetListView('daily');
                                      }else if(timeSheetSavedFrom=="weekly"){
                                      generateTimeSheetListView('weekly');
                                      }else if(timeSheetSavedFrom=="fourtnightly"){
                                      generateTimeSheetListView('fourtnightly');
                                      }else if(timeSheetSavedFrom=="monthly"){
                                      generateTimeSheetListView('monthly');
                                      }else{
                                      generateTimeSheetListView('list');
                                      }
                                      });
                            }else{
                            showAlert("Unable to submit timesheet please try again.", "Timesheet");
                            hideLoadingIcon();
                            }
                            });

    }else{
        console.log("cancel");
    }
    
}

/*--End of function --*/


/*--Function to delete timesheet (only if it is saved or rejected it can be deleted) --*/

function deleteTimeSheet(ind){
    if(ind==1){
    timeSheetWebService("POST", "DeleteTimesheetEntry", parameter, function(response) {
                        //console.log(JSON.stringify(response));
                        if(response.DeleteTimesheetEntryResult){
                        hideLoadingIcon();
                        showAlert("Timesheet Deleted Successfully.", "Timesheet", function(){
                                  if(timeSheetSavedFrom=="daily"){
                                  generateTimeSheetListView('daily');
                                  }else if(timeSheetSavedFrom=="weekly"){
                                  generateTimeSheetListView('weekly');
                                  }else if(timeSheetSavedFrom=="fourtnightly"){
                                  generateTimeSheetListView('fourtnightly');
                                  }else if(timeSheetSavedFrom=="monthly"){
                                  generateTimeSheetListView('monthly');
                                  }else{
                                  generateTimeSheetListView('list');
                                  }
                                  fromViewPg = 0;
                                  });
                        
                        }else{
                        hideLoadingIcon();
                        showAlert("Unable To Delete Timesheet.", "Timesheet");
                        }
                        });
    }else{
        console.log("same pg");
    }

}

/*--End of function --*/

/*--Function to cancel timesheet from view timesheet page--*/

function timeSheetCancel(){
    
    promptAlert("Are you sure you want to cancel the changes?", cancelTimeSheet, "Timesheet", "Yes", "No");
    
}


function cancelTimeSheet(index){
    if(index=="1"){
        if(fromPg == "timeSheetButtonPg"){
            console.log("no need to generatetimesheet");
            changePage("#timeSheetButtonPg", "slide", true);
        }else{
            generateTimeSheetListView(generatingTimesheetListViewType);
            fromViewPg = 0;
            changePage("#timeSheetPg", "slide", true);
        }
        
    }else if(index=="2"){
        console("no op");
    }
}


/*--End of function --*/
