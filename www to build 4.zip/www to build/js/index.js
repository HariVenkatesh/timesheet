
/*-- Global Variable Declarations --*/

//var webServiceURL = "http://172.16.11.79:800/IOTimeSheetsServices.svc/restful/";

var webServiceURL = "http://123.255.250.197:2239/IOTimeSheetsServices.svc/restful/";
var db;
var parameter;
var i;
var j=0;
var jobName;
var taskName;
var units;
var lineNumber;
var str;
var now;
var day;
var month;
var fullDate;
var submitFullDate;
var year;
var timeSheetStatus;
var hoursTypeListArray = [];
var jobListArray = [];
var taskListArray = [];
var taskListArrayAutoComplete = [];
var jobno;
var fromViewPg = 0;
var first;
var last;
var firstFullDate;
var lastFullDate;
var fortNightDays;
var timeSheetSavedFrom;
var hoursTypeTextFieldValue;
var jobListTextFieldValue;
var taskListTextFieldValue;
var payRollPeriodStartingDate;
var payRollPeriodEndingDate;
var payRollPeriods = [];
var yesterday;
var HoursPerWeek;
var timeSheetEmpName;
var empWorkedHours;
var fromPg;
var weeklyPeriod;
var weeklyPeriodSplit;
var pwdRegEx = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@!*#?&^_.:~`|])[A-Za-z\d$@!*#?&^_.:~`|]{8,}$/;
var popUpDeleteIcon;
//var pwdRegEx = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;

/*-- Device Ready Function Call Everytime When App Lauches --*/

document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
   
    StatusBar.styleLightContent();
    StatusBar.overlaysWebView(false);
    StatusBar.backgroundColorByHexString("#375BAA");
    
}

/*-- Resume Function Calls Everytime When App Lauches from background --*/

document.addEventListener("resume", appWhenResumedFromBackground, false);

/*-- Function to change to login page when app restore from background location --*/

function appWhenResumedFromBackground(){

    changePage("#timeSheetLoginPg", "slide", true);
    $("#timeSheetPlantEntry").prop("checked",false).checkboxradio("refresh");
}

/*-- Function Calls When User Press Android BackButton --*/

//document.addEventListener("deviceready", androidBackButtonPress, false);
//
//function androidBackButtonPress(e){
//    
//    if(device.platform == "android" || device.platform == "Android"){
//        if(type=="submit"){
//            e.preventDefault();
//        }
//        
//    }
//}

/*-- Pagecontainershow --*/

/*-- Function Call Based On Page ID --*/

$(document).on("pagecontainershow", function(event, ui) {
               
               var activePage = $.mobile.pageContainer.pagecontainer("getActivePage");
               
               activePageName = activePage.attr('id');
               
               switch (activePage.attr('id')) {
//               case 'timeSheetLoginPg':
//               clearAllFieldsOfLoginPg();
//               break;
               case 'timeSheetChangePasswordPg':
               clearAllFieldsOfChangePwdPg();
               break;
               case 'timeSheetPg':
               timeSheetEmptyFromToDateField();
               break;
//               case 'timeSheetButtonPg':
//               getEmpDetails();
//               break;
               }
               });


/*-- Pagecontainershow End --*/

/*-- Common Method To Shows Dialog Box --*/

function showAlert(alertmessage, title, callBack_func) {
    if (callBack_func) {
        navigator.notification.alert(alertmessage, callBack_func, title, "OK");
    } else {
        navigator.notification.alert(alertmessage, false, title, "OK");
    }
}

/*-- Dialog Box Method End --*/

/*-- Common Prompt Alert --*/

function promptAlert(alertmessage, callBack_func, title, buttonLabels1, buttonLabels2) {
    
    if (callBack_func) {
        navigator.notification.confirm(alertmessage, callBack_func, title, [buttonLabels1, buttonLabels2]);
    } else {
        navigator.notification.confirm(alertmessage, false, title, [buttonLabels1, buttonLabels2]);
    }
}

/*-- End Common Prompt Alert --*/



/*-- Common Prompt Alert --*/

function multiplePromptAlert(alertmessage, callBack_func, title, buttonLabels1, buttonLabels2, buttonLabels3) {
    
    if (callBack_func) {
        navigator.notification.confirm(alertmessage, callBack_func, title, [buttonLabels1, buttonLabels2, buttonLabels3]);
    } else {
        navigator.notification.confirm(alertmessage, false, title, [buttonLabels1, buttonLabels2, buttonLabels3]);
    }
}

/*-- End Common Prompt Alert --*/






/*-- ChangePage Function --*/

function changePage(pagename, pageTransition, isReverse) {
    
    $.mobile.changePage(pagename, {
                        transition: pageTransition,
                        changeHash: false,
                        reverse: isReverse
                        });
    
}

/*-- End of ChangePage Function --*/


/*-- Method To Check Internet Connection --*/

function checkConnection() {
    
    var networkState = navigator.connection.type;
    var states = {};
    states[Connection.UNKNOWN] = 'Unknown connection';
    states[Connection.ETHERNET] = 'Ethernet connection';
    states[Connection.WIFI] = 'WiFi connection';
    states[Connection.CELL_2G] = 'Cell 2G connection';
    states[Connection.CELL_3G] = 'Cell 3G connection';
    states[Connection.CELL_4G] = 'Cell 4G connection';
    states[Connection.NONE] = 'No network connection';
    if (states[networkState] == 'No network connection') {
        return false;
    } else {
        return true;
    }
}

/*-- End of Internet Connection Method --*/


/*-- Common Method To Show Loading Icon While Calling Webservice  --*/

function Apploadingicon() {
    
    $("body").append("<div class='modalWindow'/>");
    $("body").bind("touchmove", function(e) {
                   e.preventDefault()
                   });
    $.mobile.loading("show", {
                     text: "Loading...",
                     textVisible: true,
                     theme: "b",
                     html: ""
                     });
    
}

/*-- End Of Loading Icon Method --*/


/*-- Method To Hide App Loading Icon --*/

function hideLoadingIcon() {
    
    $("body").unbind("touchmove");
    $(".modalWindow").remove();
    $.mobile.loading("hide");
    
}

/*-- End Of Method App Loading Icon --*/


/*-- Exception Handling Method --*/

function errorHandling(originalCode) {
    try {
        originalCode();
    } catch (err) {
        alert(err.message);
    }
}

/*-- End Of Exception Handling Block --*/


/*-- Common Method To Hit WebService  --*/

function timeSheetWebService(requestType, methodName, param, callBack) {
    
    errorHandling(function() {
                  Apploadingicon();
                  if (checkConnection()) {
                  $.ajax({
                         type: "" + requestType + "",
                         url: webServiceURL + "" + methodName + "",
                         data: JSON.stringify(param),
                         dataType: "json",
                         contentType: "application/json; charset=utf-8",
                         success: function(msg) {
                         callBack(msg);
                         },
                         error: function(xhr) {
                         console.log(JSON.stringify(xhr));
                         showAlert("Webservice Error", "Timesheet");
                         hideLoadingIcon();
                         }
                         });
                  } else {
                  showAlert("Please check internet connection.", "Timesheet");
                  hideLoadingIcon();
                  }
                  });
}

/*-- End Of Common WebService Method --*/


/*-- Logout Function --*/

function timeSheetLogout(){
    Apploadingicon();
    promptAlert("Are you sure you want to logout?", logout, "Timesheet", "Yes", "No");
}

function logout(btnIndex){
    if(btnIndex==1){
        hideLoadingIcon();
        changePage("#timeSheetLoginPg", "slide", true);
    }else{
        hideLoadingIcon();
        //console.log("stay in same page");
    }
    
}

/*-- End Of Logout Function --*/


/*-- Clear all fields of changepassword screen */

function clearAllFieldsOfChangePwdPg(){
    $("#timeSheetOldPwd").val("");
    $("#timeSheetNewPwd").val("");
    $("#timeSheetConfirmNewPwd").val("");
}

/*-- End Of Function --*/

/*-- Change Password Function */

function timeSheetChangePassword(){
    
    if(($("#timeSheetOldPwd").val()== "") && ($("#timeSheetNewPwd").val()== "") && ($("#timeSheetConfirmNewPwd").val()== "")){
        showAlert("Please enter all fields","Timesheet", function(){
                  $("#timeSheetOldPwd").focus();
                  });
    }else if($("#timeSheetOldPwd").val()== ""){
        showAlert("Please enter old password ","Timesheet", function(){
                  $("#timeSheetOldPwd").focus();
                  });
    }else if($("#timeSheetNewPwd").val()== ""){
        showAlert("Please enter new password ","Timesheet", function(){
                  $("#timeSheetNewPwd").focus();
                  });
    }else if($("#timeSheetConfirmNewPwd").val()== ""){
        showAlert("Please enter confirm password ","Timesheet", function(){
                  $("#timeSheetConfirmNewPwd").focus();
                  });
    }else if(!(pwdRegEx.test($("#timeSheetConfirmNewPwd").val()))){
        showAlert("Password should have atlease one alphabet, one special symbols/characters and minimum of 8 characters ","Timesheet");
    }else {
        
        if($("#timeSheetNewPwd").val() != $("#timeSheetConfirmNewPwd").val()){
            showAlert("New password & confirm password doesn't match ","Timesheet");
        }else{
        
        parameter = {"employee":{
            "EmployeeNo": localStorage.getItem("timeSheetEmployeeNumber"),
            "Password": $("#timeSheetOldPwd").val(),
            "CurrentPassword":$("#timeSheetNewPwd").val()
        }}
            
        //console.log(JSON.stringify(parameter));
        timeSheetWebService("POST", "ChangeCurrentPassword", parameter, function(response) {
                               // console.log("ChangeCurrentPassword"+JSON.stringify(response));
                                if (response.ChangeCurrentPasswordResult) {
                                hideLoadingIcon();
                                showAlert("Password changed successfully", "Timesheet", function(){
                                changePage("#timeSheetLoginPg","slide",true);
                                      });
                                } else {
                                hideLoadingIcon();
                                showAlert("Unable to change password please tryagain later.", "Timesheet");
                                }
                            
                                });
        }
            
        }
    }


/*-- End Of Change Password Function --*/

/*--Function To Clear All Fields Of Login Page--*/

function clearAllFieldsOfLoginPg()
{
    /*-- Code to change the theme color while login and logout--*/
    
    if(($("#timeSheetsTheme").val())=="template1"){
        $(".ui-btn, .ui-header").css({"background-color":"#74203f","color":"#ffffff","text-shadow":"none","border-color":"#74203f"});
        $(".timeSheetsTheme").css({"color":"#74203f"});
    }else if(($("#timeSheetsTheme").val())=="default"){
        $(".ui-btn, .ui-header").css({"background-color":"#375BAA","color":"#ffffff","text-shadow":"none","border-color":"#375BAA"});
        $(".timeSheetsTheme").css({"color":"#375BAA"});
    }
    
    $("#timeSheetLoginPgUserName").val("");
    $("#timeSheetLoginPgPassword").val("");
}

/*-- End Of Function --*/


/*-- Timesheet Function To Change Theme Throught The Application --*/

function timeSheetThemeChange(){
    
    if(($("#timeSheetsTheme").val())=="template1"){
        $("[data-role=page]").page({theme:"a"});
        StatusBar.backgroundColorByHexString("#74203f");
        $(".timeSheetPlantEntryHeading").css("background-color","#74203f");
        $(".viewAllTimesheetStyle, label").css("color","#74203f");
        $(".timeSheetEmpName, .timeSheetMinWrkingHrs, .timeSheetMaxWrkingHrs").css("color","#74203f");
        $(".ui-btn").css({"background-color":"#74203f","color":"#ffffff","text-shadow":"none","border-color":"#74203f"});
        $(".ui-header").css({"background-color":"#74203f","color":"#ffffff","border-color":"#74203f","text-shadow":"none"});
        $(".ui-input").css("color","#1D1D1D");
        $(".ui-select, .ui-btn, select").css("border-color","#ffffff");
        $(".infoIcon").css({"background-color":"#74203f","border-color":"#74203f"});
    }else if(($("#timeSheetsTheme").val())=="default"){
        
        $("[data-role=page]").page({theme:"a"});
        StatusBar.backgroundColorByHexString("#375BAA");
        $(".timeSheetPlantEntryHeading").css("background-color","#375BAA");
        $(".viewAllTimesheetStyle, label").css("color","#375BAA");
        $(".timeSheetEmpName,.timeSheetMinWrkingHrs,.timeSheetMaxWrkingHrs").css("color","#375BAA");
        $(".ui-btn").css({"background-color":"#375BAA","color":"#ffffff","text-shadow":"none","border-color":"#375BAA"});
        $(".ui-header").css({"background-color":"#375BAA","color":"#ffffff","border-color":"#375BAA","text-shadow":"none"});
        $(".ui-input").css("color","#ffffff");
        $(".ui-select, .ui-btn, select").css("border-color","#ffffff");
        $(".infoIcon").css({"background-color":"#375BAA","border-color":"#375BAA"});
    }
    
}

/*-- End Of Function --*/


/*-- Timesheet Login Function --*/

function timesheetLogin(){
    
    fromPg = $.mobile.activePage.attr("id");
    if($("#timeSheetLoginPgUserName").val()==""||$("#timeSheetLoginPgUserName").val()==" "||$("#timeSheetLoginPgUserName").val()==undefined || $("#timeSheetLoginPgUserName").val()== null){
        showAlert("Please enter your username","Timesheet", function(){
                  $("#timeSheetLoginPgUserName").focus();
                  });
    }else if($("#timeSheetLoginPgPassword").val()==""||$("#timeSheetLoginPgPassword").val()==" "||$("#timeSheetLoginPgPassword").val()==undefined || $("#timeSheetLoginPgPassword").val()== null){
        showAlert("Please enter your password","Timesheet", function(){
                  $("#timeSheetLoginPgPassword").focus();
                  });
    }else{
        
        if(($("#timeSheetsTheme").val())=="template1"){
                       $("[data-role=page]").page({theme:"a"});
                       StatusBar.backgroundColorByHexString("#74203f");
                       $(".timeSheetPlantEntryHeading").css("background-color","#74203f");
                       $(".viewAllTimesheetStyle, label").css("color","#74203f");
                       $(".timeSheetEmpName, .timeSheetMinWrkingHrs, .timeSheetMaxWrkingHrs").css("color","#74203f");
                       $(".ui-btn").css({"background-color":"#74203f","color":"#ffffff","text-shadow":"none","border-color":"#74203f"});
                       $(".ui-header").css({"background-color":"#74203f","color":"#ffffff","border-color":"#74203f","text-shadow":"none"});
                       $(".ui-input").css("color","#1D1D1D");
                       $(".ui-select, .ui-btn, select").css("border-color","#ffffff");
                       $(".infoIcon").css({"background-color":"#74203f","border-color":"#74203f"});
            
            //                       $(".timeSheetMinWrkingHrs").css("color","#74203f");
            //                       $(".timeSheetMaxWrkingHrs").css("color","#74203f");
            //                       $("label").css("color","#74203f");
            //                       $("[data-role=page]").page({data-theme:"c"});
            //                       $(".ui-header").css("color","#ffffff");
            //                       $(".ui-btn").css("color","#ffffff");
            //                       $(".ui-btn").css("text-shadow","none");
            
            /*-- Orange:  RGB {255:127:0}  HEX: FF7F00
             Blue: RGB {55:91:170}  HEX: 375BAA --- 007CDE - outlook color --*/
            
        }else if(($("#timeSheetsTheme").val())=="default"){
            
                        $("[data-role=page]").page({theme:"a"});
                        StatusBar.backgroundColorByHexString("#375BAA");
                        $(".timeSheetPlantEntryHeading").css("background-color","#375BAA");
                        $(".viewAllTimesheetStyle, label").css("color","#375BAA");
                        $(".timeSheetEmpName,.timeSheetMinWrkingHrs,.timeSheetMaxWrkingHrs").css("color","#375BAA");
                        $(".ui-btn").css({"background-color":"#375BAA","color":"#ffffff","text-shadow":"none","border-color":"#375BAA"});
                        $(".ui-header").css({"background-color":"#375BAA","color":"#ffffff","border-color":"#375BAA","text-shadow":"none"});
                        $(".ui-input").css("color","#ffffff");
                        $(".ui-select, .ui-btn, select").css("border-color","#ffffff");
                        $(".infoIcon").css({"background-color":"#375BAA","border-color":"#375BAA"});
            
            //                        $(".timeSheetMinWrkingHrs").css("color","#007CDE");
            //                        $(".timeSheetMaxWrkingHrs").css("color","#007CDE");
            //                        $("label").css("color","#007CDE");
            //                        $("[data-role=page]").page({data-theme:"c"});
            //                        $("#plantno select").css("background-color","#F9F9F9");
            //                        $("#plantno select").css("color","#1D1D1D");
            //                        $(".ui-btn").css("color","#ffffff");
            //                        $(".ui-btn").css("text-shadow","none");
            //                        $(".ui-header").css("color","#ffffff");
            
            
                    }
        parameter = {
            "employee":{
            "EmployeeNo": $("#timeSheetLoginPgUserName").val(),
            "Password": $("#timeSheetLoginPgPassword").val()
        }
        }
        
        //changePage("#timeSheetButtonPg","slide",false);
        timeSheetWebService("POST", "GetEmployee", parameter, function(response) {
                   //console.log("Login"+JSON.stringify(response));
                   if (response.GetEmployeeResult.Status) {
                   localStorage.setItem("timeSheetEmployeeNumber",$("#timeSheetLoginPgUserName").val());
                   localStorage.setItem("timeSheetPayRollNumber",response.GetEmployeeResult.PayrollNumber);
                   generateTimeSheetListView("weekly");
                   timeSheetEmpName = response.GetEmployeeResult.FullName;
                   HoursPerWeek = response.GetEmployeeResult.HoursPerWeek;
                   hideLoadingIcon();
                   changePage("#timeSheetButtonPg","slide",false);
                   } else {
                   hideLoadingIcon();
                   showAlert("Invalid Username or Password.", "Timesheet");
                   }
                            });
  
    }
}


/*-- End Of Login Function --*/

function getEmpDetails(){
    $(".timeSheetEmpName").text(timeSheetEmpName);
    $(".timeSheetMinWrkingHrs").text("Min Hrs: "+HoursPerWeek);
    
    if(empWorkedHours==undefined || empWorkedHours==null){
        $(".timeSheetMaxWrkingHrs").text("Hrs Worked: 0");
    }else{
        $(".timeSheetMaxWrkingHrs").text("Hrs Worked: " + empWorkedHours);
    }
    
}


/*-- Timesheet Clear Filter Date Fields Function & get payperiods selectbox value i.e month details --*/

function timeSheetEmptyFromToDateField(){
    $("#timeSheetPgFrom").val("");
    $("#timeSheetPgTo").val("");
    $("#timeSheetPgWeeklyPeriod").empty("");
    $("#timeSheetPgWeeklyPeriod").append("<option value='0'>Weekly Periods</option>");
    $("#timeSheetPgWeeklyPeriod").selectmenu().selectmenu("refresh");
    
    parameter = {
        "payrollNumber":localStorage.getItem("timeSheetPayRollNumber")
    }
    
//    console.log(JSON.stringify(parameter));
    timeSheetWebService("POST", "GetPayrollPeriods", parameter, function(response) {
                        //console.log("asfdasdf"+JSON.stringify(response));
                        if ((response.GetPayrollPeriodsResult == null) || (response.GetPayrollPeriodsResult == "") || (response.GetPayrollPeriodsResult == undefined)){
                        hideLoadingIcon();
                        showAlert("Pay Periods not found please tryagin later .", "Timesheet");
                        }else{

                        for(i=0;i<response.GetPayrollPeriodsResult.length;i++){
                        
                        str = response.GetPayrollPeriodsResult[i].StartingDate;
                        str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                        now = new Date(+str);
                        day = ("0" + now.getDate()).slice(-2);
                        month = ("0" + (now.getMonth() + 1)).slice(-2);
                        payRollPeriodStartingDate = day+"-"+month+"-"+now.getFullYear();
                        
                        str = response.GetPayrollPeriodsResult[i].EndingDate;
                        str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                        now = new Date(+str);
                        day = ("0" + now.getDate()).slice(-2);
                        month = ("0" + (now.getMonth() + 1)).slice(-2);
                        payRollPeriodEndingDate = day+"-"+month+"-"+now.getFullYear();
                        
                        payRollPeriods[i] = {"startingDate":payRollPeriodStartingDate, "endingDate":payRollPeriodEndingDate, "IsCurrent":response.GetPayrollPeriodsResult[i].IsCurrent, "IsLocked":response.GetPayrollPeriodsResult[i].IsLocked, "Number":response.GetPayrollPeriodsResult[i].Number};
                        
                        }
                        $("#timeSheetPgPayRollPeriod").empty("");
                        $("#timeSheetPgPayRollPeriod").append("<option value='0'>Payroll Periods</option>");
                        for(i=0;i<payRollPeriods.length;i++){
                        
                        $("#timeSheetPgPayRollPeriod").append("<option value="+payRollPeriods[i].Number+">"+payRollPeriods[i].startingDate+" to "+payRollPeriods[i].endingDate+"</option>");
                        $("#timeSheetPgPayRollPeriod").selectmenu().selectmenu("refresh");
                        }
                        hideLoadingIcon();
                        //console.log("sfdsdfasdff"+JSON.stringify(payRollPeriods));
                        }
                        });
    
    
    
}

/*-- End Of Clear Filter Date Fields Function --*/

/*-- Depending on the payperiod month the weekly period will be generated--*/

$("#timeSheetPgPayRollPeriod").change(function (){
        
        //alert($("#timeSheetPgPayRollPeriod :selected").text());
        
        parameter = { "payPeriod":$("#timeSheetPgPayRollPeriod :selected").text() }
                                      
        //console.log(JSON.stringify(parameter));
        if($("#timeSheetPgPayRollPeriod :selected").text()=="Payroll Periods"){
                                      $("#timeSheetPgWeeklyPeriod").empty("");
                                      $("#timeSheetPgWeeklyPeriod").append("<option value='0'>Weekly Periods</option>");
                                      $("#timeSheetPgWeeklyPeriod").selectmenu("refresh", true);
        }else{
        timeSheetWebService("POST", "GetWeeksforPayPeriod", parameter, function(response) {
                //console.log("asfdasdf"+JSON.stringify(response));
                            if ((response.GetWeeksforPayPeriodResult == null) || (response.GetWeeksforPayPeriodResult == "") || (response.GetWeeksforPayPeriodResult == undefined)){
                            hideLoadingIcon();
                            showAlert("Weekly Periods not found please try agin later .", "Timesheet");
                            }else{
                            $("#timeSheetPgWeeklyPeriod").empty("");
                            $("#timeSheetPgWeeklyPeriod").append("<option value='0'>Weekly Periods</option>");
                            for(i=0;i<response.GetWeeksforPayPeriodResult.length;i++){
                            
                            $("#timeSheetPgWeeklyPeriod").append("<option value="+response.GetWeeksforPayPeriodResult[i].Value+">"+response.GetWeeksforPayPeriodResult[i].Text+"</option>");
                            $("#timeSheetPgWeeklyPeriod").selectmenu().selectmenu("refresh");
                            
                            }
                            }
                            hideLoadingIcon();
                            });
            }
                                      });



/*-- End Of Function --*/



function timeSheetAutoFillFromToDateField(){

     Apploadingicon();
     weeklyPeriod = $("#timeSheetPgWeeklyPeriod :selected").text();
     weeklyPeriodSplit = weeklyPeriod.split("-");
     weeklyPeriod = weeklyPeriodSplit[2]+"-"+weeklyPeriodSplit[1]+"-"+weeklyPeriodSplit[0];
    
    
    now = new Date(weeklyPeriod);
    first = now.getDate() - now.getDay();
    first = new Date(now.setDate(first)).toUTCString();
    lastFullDate = new Date(first);
    
    lastFullDate.setDate(lastFullDate.getDate() + 7);
    day = lastFullDate.getDate();
    month = lastFullDate.getMonth() + 1;
    year = lastFullDate.getFullYear();
    
    if(day<10){
        day = "0"+day;
    }
    
    if(month<10){
        month = "0"+month;
    }
    
    lastFullDate = year+"-"+month+"-"+day;
    
    $("#timeSheetPgTo").val(lastFullDate);
    $("#timeSheetPgFrom").val(weeklyPeriod);
    hideLoadingIcon();
}



/*-- Timesheet Listview Function to fix parameter based on daily, weekly, monthly & fourtnightly--*/

function generateTimeSheetListView(type){

    if(type=="filter"){

        if(($("#timeSheetPgFrom").val() == "") && ($("#timeSheetPgTo").val() == "") && ($("#timeSheetPgPayRollPeriod :selected").text() == "Payroll Periods") && ($("#timeSheetPgWeeklyPeriod :selected").text() == "Weekly Period")){
            showAlert("Please enter any of filter by option to filter", "Timesheet");
        
        }else if(($("#timeSheetPgPayRollPeriod :selected").text() == "Payroll Periods") && ($("#timeSheetPgWeeklyPeriod :selected").text() == "Weekly Period")){
            
            if(($("#timeSheetPgFrom").val() == "") || ($("#timeSheetPgTo").val() == "")){
                if($("#timeSheetPgFrom").is(":visible")){
                showAlert("Please enter from and to date to filter", "Timesheet");
                }else{
                    console.log("no from to btn displayed to show");
                }
            }
            
        }else if(($("#timeSheetPgFrom").val() == "") || ($("#timeSheetPgTo").val() == "")){
            if($("#timeSheetPgFrom").is(":visible")){
                showAlert("Please enter from and to date to filter", "Timesheet");
            }else{
                console.log("no from to btn displayed to show");
            }
           
        }else{
            
            parameter = {
                    "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
                    "startDate":"" +$("#timeSheetPgFrom").val()+ "",
                    "endDate":"" +$("#timeSheetPgTo").val()+ ""
                }
            generatingTimesheetListView("filter");
        }
    }else if(type=="list"){
        
        timeSheetSavedFrom = "list";
        $("#timeSheetPgFrom").val("");
        $("#timeSheetPgTo").val("");
        $(".subHeaderLableLeftPadding").show();
        $(".timeSheetPgFrom").show();
        $(".timeSheetPgTo").show();
        

        parameter = { "employeeNum": localStorage.getItem("timeSheetEmployeeNumber") };
        
        generatingTimesheetListView("list");
        
    }else if(type=="daily"){
       
        /*code to find daily date*/

        /* Hide all filter for daily */
        
        $(".subHeaderLableLeftPadding").hide();
        
        timeSheetSavedFrom = "daily";
        now = new Date();
        day = now.getDate();
        month = now.getMonth()+1;
        year = now.getFullYear();
        
        if(day<10){
           day = "0"+day;
        }
        
        if(month<10){
            month = "0"+month;
        }
        
         firstFullDate = day+"-"+month+"-"+year;
         lastFullDate = day+"-"+month+"-"+year;
        
        parameter = {
            "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
            "startDate":"" +firstFullDate+ "",
            "endDate":"" +lastFullDate+ ""
        }
        generatingTimesheetListView("daily");
        
    }else if(type=="weekly"){
        
        /*Hide from and to filter alone*/
        
        $(".subHeaderLableLeftPadding").show();
        $(".timeSheetPgFrom").hide();
        $(".timeSheetPgTo").hide();

        /*code to find 1st and last day of the current week*/
        timeSheetSavedFrom = "weekly";
        now = new Date();
        first = now.getDate() - now.getDay();
        first = new Date(now.setDate(first)).toUTCString();
        
//last = new Date(now.setDate(last)).toUTCString();
        
        /* Code to find 1st day of week */
        
        firstFullDate = new Date(first);
        lastFullDate = new Date(first);
        
        day = firstFullDate.getDate();
        weeklyStartDate = firstFullDate.getDate();
        if(day<10){
            day = "0"+day;
        }
        
        month = firstFullDate.getMonth()+1;
        if(month<10){
            
            month = "0"+month;
        }
        
        year = firstFullDate.getFullYear();
        firstFullDate = day+"-"+month+"-"+year;
        
         /* Code to find last day of week*/
        
        lastFullDate.setDate(lastFullDate.getDate() + 6);
        day = lastFullDate.getDate();
        month = lastFullDate.getMonth() + 1;
        year = lastFullDate.getFullYear();
        
        if(day<10){
            day = "0"+day;
        }

        if(month<10){
            month = "0"+month;
        }
        
        lastFullDate = day+"-"+month+"-"+year;
       
        parameter = {
            "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
            "startDate":"" +firstFullDate+ "",
            "endDate":"" +lastFullDate+ ""
        }
        generatingTimesheetListView("weekly");
        
    /*list to show  14 days before from current days*/
        
    }else if(type=="fourtnightly"){
        
        /*Show all filter*/
        
        $(".subHeaderLableLeftPadding").show();
        $(".timeSheetPgFrom").show();
        $(".timeSheetPgTo").show();
        
         /* Code to find last day of 14 days*/
        
        timeSheetSavedFrom = "fourtnightly";
        lastFullDate = new Date();
        
        day = lastFullDate.getDate();
        if(day<10){
            day = "0"+day;
        }
        
        month = lastFullDate.getMonth()+1;
        if(month<10){
            month = "0"+month;
        }
        
        year = lastFullDate.getFullYear();
        lastFullDate = day+"-"+month+"-"+year;
        
       /* Code to find first day of 14 days*/
        
        fortNightDays = new Date(+new Date - 12096e5);
        
        day = fortNightDays.getDate();
        if(day<10){
            day = "0"+day;
        }

        month = fortNightDays.getMonth()+1;
        if(month<10){
            month = "0"+month;
        }
        year = fortNightDays.getFullYear();
        
        firstFullDate = day+"-"+month+"-"+year;
        
        parameter = {
            "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
            "startDate":"" +firstFullDate+ "",
            "endDate":"" +lastFullDate+ ""
        }
        
        generatingTimesheetListView("fourtnightly");
        
    }else if(type=="monthly"){
        
        /*Show all filter*/
        
        $(".subHeaderLableLeftPadding").show();
        $(".timeSheetPgFrom").show();
        $(".timeSheetPgTo").show();
        
        timeSheetSavedFrom = "monthly";
        
        /* Code to find before 30 days*/
        
        now = new Date();
        firstFullDate = new Date(now.getFullYear(),now.getMonth(),1);
        lastFullDate =  new Date(now.getFullYear(),now.getMonth()+1,0);
        
        firstFullDate = firstFullDate.getDate()+"-"+(firstFullDate.getMonth()+1)+"-"+firstFullDate.getFullYear();
        lastFullDate = lastFullDate.getDate()+"-"+(lastFullDate.getMonth()+1)+"-"+lastFullDate.getFullYear();

        parameter = {
            "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
            "startDate":"" +firstFullDate+ "",
            "endDate":"" +lastFullDate+ ""
        }
        
        generatingTimesheetListView("monthly");
    }
}


/*-- Function to generate listview based on above parameter 
 Note: also list is diffrentiated based on submitted, approved, saved and rejected method  
 0 - saved
 1 - pending  which meanse submitted orange
 2 - confirm  approved green
 3 - rejected red  --*/

function generatingTimesheetListView(type){
    
 
    timeSheetWebService("POST", "GetTimesheetEntries", parameter, function(response) {
                        //console.log("GetTimesheetEntries"+JSON.stringify(response));
                        if (response.GetTimesheetEntriesResult.length==0 || response.GetTimesheetEntriesResult.length==null) {
                       
                        hideLoadingIcon();
                        if(fromPg=="timeSheetLoginPg"){
                        fromPg = "";
                        console.log("dont show alert");
                        }else{
                        if(type=="filter"){
                        $("#timeSheetListview").empty();
                        showAlert("No Timesheet found to show!", "Timesheet");
                        }else{
                        $("#timeSheetListview").empty();
                        showAlert("No Timesheet found to show!", "Timesheet", function(){
                                  changePage("#timeSheetButtonPg","slide",true);
                                  });
                        }
                        }
                        getEmpDetails();
                        }else{
                        $("#timeSheetListview").empty();
                        empWorkedHours = 0;
                        for(i=0;i<response.GetTimesheetEntriesResult.length;i++){
                        jobName = response.GetTimesheetEntriesResult[i].JobFullDescription;
                        taskName = response.GetTimesheetEntriesResult[i].JobTaskFullDescription;
                        units = response.GetTimesheetEntriesResult[i].Units;
                        lineNumber = response.GetTimesheetEntriesResult[i].LineNumber;
                        timeSheetStatus = response.GetTimesheetEntriesResult[i].TimesheetStatus;
                        
                        /*To calculate working hours of each employee for every week*/
                        
                        if(type=="weekly"){
                        if((timeSheetStatus == 1) || (timeSheetStatus == 2)){
                        empWorkedHours = empWorkedHours + units;
                        //console.log("wrjedgrs:"+empWorkedHours);
                        }
                        getEmpDetails();
                        }
                        
                        
                        /* Date Conversion */
                        
                        str = response.GetTimesheetEntriesResult[i].WorkDate;
                        str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                        now = new Date( +str );
                        day = ("0" + now.getDate()).slice(-2);
                        month = ("0" + (now.getMonth() + 1)).slice(-2);
                        year = now.getFullYear();
                        fullDate = "" +day+"/"+month+"/"+year+ "";
                        
                        if(timeSheetStatus == 0){
                        $("#timeSheetListview").append("<li data-icon='false' style='white-space:normal;'><div><div class='timeSheetListViewHeaderLeftPos'></div><div class='timeSheetListViewHeaderCenterPos'></div><div class='timeSheetListViewHeaderRightPos'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-truck ui-btn-icon-notext infoIcon' onclick='timeSheetViewPlantEntry(\""+lineNumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+lineNumber+"\");'>Job: "+jobName+"<br>Task: "+taskName+"<br>Date: "+fullDate+"<br>Hours: "+units+"</div></li>");
                        }else if(timeSheetStatus == 1){
                        $("#timeSheetListview").append("<li data-icon='false' style='white-space:normal;'><div><div class='timeSheetListViewHeaderLeftPos' style='color:darkorange;'>Submitted</div><div class='timeSheetListViewHeaderCenterPos'></div><div id='truckIcon"+lineNumber+"' class='timeSheetListViewHeaderRightPos'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-truck ui-btn-icon-notext infoIcon' onclick='timeSheetViewPlantEntry(\""+lineNumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+lineNumber+"\");'>Job: "+jobName+"<br>Task: "+taskName+"<br>Date: "+fullDate+"<br>Hours: "+units+"</div></li>");
                        
                        //$("#truckIcon"+lineNumber).hide();
                        
                        }else if(timeSheetStatus == 2){
                        $("#timeSheetListview").append("<li data-icon='false' style='white-space:normal;'><div><div class='timeSheetListViewHeaderLeftPos' style='color:green;'>Approved</div><div class='timeSheetListViewHeaderCenterPos'></div><div class='ui-nodisc-icon timeSheetListViewHeaderRightPos'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-truck ui-btn-icon-notext infoIcon' onclick='timeSheetViewPlantEntry(\""+lineNumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+lineNumber+"\");'>Job: "+jobName+"<br>Task: "+taskName+"<br>Date: "+fullDate+"<br>Hours: "+units+"</div></li>");
                        }else if(timeSheetStatus == 3){
                        $("#timeSheetListview").append("<li data-icon='false' style='white-space:normal;'><div><div class='timeSheetListViewHeaderLeftPos' style='color:red;'>Rejected</div><div class='timeSheetListViewHeaderCenterPos'></div><div class='ui-nodisc-icon timeSheetListViewHeaderRightPos'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-truck ui-btn-icon-notext infoIcon' onclick='timeSheetViewPlantEntry(\""+lineNumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+lineNumber+"\");'>Job: "+jobName+"<br>Task: "+taskName+"<br>Date: "+fullDate+"<br>Hours: "+units+"</div></li>");
                        }
                        }
                        if(($("#timeSheetsTheme").val())=="template1"){
                        $(".infoIcon").css({"background-color":"#74203f","border-color":"#74203f"});
                        }else if(($("#timeSheetsTheme").val())=="default"){
                        $(".infoIcon").css({"background-color":"#375BAA","border-color":"#375BAA"});
                        }
                        hideLoadingIcon();
                        if(fromPg=="timeSheetLoginPg"){
                        console.log("Dont changePg");
                        fromPg = "";
                        }else{
                        changePage("#timeSheetPg","slide",false);
                        }
                        }
                         $("#timeSheetListview").listview("refresh");
                        });
    
    
    /* List Data by storing in local db
     
     changePage("#timeSheetPg","slide",false);
     db = window.sqlitePlugin.openDatabase({name: 'timeSheet.db', location: 'default'});
     console.log("db created successfully");
     db.transaction(function(tx) {
     tx.executeSql("DROP TABLE IF EXISTS timesheetDetails");
     tx.executeSql("CREATE TABLE IF NOT EXISTS timesheetDetails (id integer PRIMARY KEY, job TEXT, task VARCHAR(33), date STRING, hours NUMERIC, linenumber NUMERIC, timesheetstatus NUMERIC)",function(tx, res) {
     console.log("created");
     }, function(e) {
     console.log("ERROR: " + JSON.stringify(e));
     });
     for(i=0;i<response.GetTimesheetEntriesResult.length;i++){
     
     jobName = response.GetTimesheetEntriesResult[i]._jobFullDescription;
     taskName = response.GetTimesheetEntriesResult[i]._jobTaskFullDescription;
     units = response.GetTimesheetEntriesResult[i]._units;
     lineNumber = response.GetTimesheetEntriesResult[i]._lineNumber;
     var Date = response.GetTimesheetEntriesResult[i]._workDate;
     timeSheetStatus = response.GetTimesheetEntriesResult[i]._timesheetStatus;
     
     tx.executeSql("INSERT INTO timesheetDetails (job, task, date, hours, linenumber, timesheetstatus) VALUES (?,?,?,?,?,?)",[jobName, taskName, Date, units, lineNumber, timeSheetStatus],function(tx, res) {
     console.log("inserted");
     }, function(e) {
     console.log("ERROR: " + JSON.stringify(e));
     });
     }
     });
     
     db.transaction(function(tx) {
     $("#timeSheetListview").empty();
     for(var j=0;j<response.GetTimesheetEntriesResult.length;j++){
     
     tx.executeSql("select job,task,date,hours,linenumber,timesheetstatus from timesheetDetails where id="+j+";", [], function(tx, res) {
     str = res.rows.item(0).date;
     str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
     now = new Date(+str);
     day = ("0" + now.getDate()).slice(-2);
     month = ("0" + (now.getMonth() + 1)).slice(-2);
     year = now.getFullYear();
     fullDate = "" +day+"/"+month+"/"+year+ "";
     if(res.rows.item(0).timesheetstatus == 0){
     $("#timeSheetListview").append("<li data-icon='false'><div><div class='timeSheetListViewHeaderLeftPos'><img src='img/orangedot.png' class='timeSheetListViewHeaderLeftPosImg'/></div><div class='timeSheetListViewHeaderCenterPos'></div><div class='ui-nodisc-icon timeSheetListViewHeaderRightPos'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-info ui-btn-icon-notext ui-btn-b' onclick='timeSheetViewPlantEntry(\""+res.rows.item.linenumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+res.rows.item(0).linenumber+"\");'>Job: "+res.rows.item(0).job+"<br>Task:  "+res.rows.item(0).task+"<br>Date: "+fullDate+"<br>Hours:"+res.rows.item(0).hours+"</div></li>");
     }else if(res.rows.item(0).timesheetstatus == 1){
     $("#timeSheetListview").append("<li data-icon='false'><div><div class='timeSheetListViewHeaderLeftPos'><img src='img/greendot.png' style='height:13px;width:13px;'/></div><div class='timeSheetListViewHeaderCenterPos'></div><div class='ui-nodisc-icon timeSheetListViewHeaderRightPos'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-info ui-btn-icon-notext ui-btn-b' onclick='timeSheetViewPlantEntry(\""+res.rows.item.linenumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+res.rows.item(0).linenumber+"\");'>Job: "+res.rows.item(0).job+"<br>Task:  "+res.rows.item(0).task+"<br>Date: "+fullDate+"<br>Hours:"+res.rows.item(0).hours+"</div></li>");
     }else if(res.rows.item(0).timesheetstatus == 2){
     $("#timeSheetListview").append("<li data-icon='false'><div><div class='timeSheetListViewHeaderLeftPos'><img src='img/reddot.png' style='height:13px;width:13px;'/></div><div class='timeSheetListViewHeaderCenterPos'></div><div class='ui-nodisc-icon timeSheetListViewHeaderRightPos'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-info ui-btn-icon-notext ui-btn-b' onclick='timeSheetViewPlantEntry(\""+res.rows.item.linenumber+"\");'>View</a></div></div><br><br><div onclick='viewTimeSheetDetails(\""+res.rows.item(0).linenumber+"\");'>Job: "+res.rows.item(0).job+"<br>Task:  "+res.rows.item(0).task+"<br>Date: "+fullDate+"<br>Hours:"+res.rows.item(0).hours+"</div></li>");
     }
     
     $("#timeSheetListview").listview("refresh");
     hideLoadingIcon();
     });
     }
     //db.close();
     //    db.close(successcb, errorcb);
     hideLoadingIcon();
     }, function(error) {
     console.log('transaction error: ' + error.message);
     //                                       db.close();
     });
     }
     });*/
    
}


/*-- End Of Timesheet Listview Function --*/


/* Function when checkbox clicked popup opens */

$("#timeSheetPlantEntry").click(function(){
                        
/* if loop to check and apply theme for delete icon in popup, as color does not applied directly*/
                                
                              if(($("#timeSheetsTheme").val())=="template1"){
                                
                                popUpDeleteIcon = "<a href='#' class='ui-btn ui-shadow ui-corner-all ui-icon-delete ui-btn-icon-notext ui-btn-inline ui-nodisc-icon plantEntryDeleteIcon' style='background-color:#74203f;color:#ffffff;text-shadow:none;border-color:#74203f;'>Delete</a>" ;
                                
                              }else if(($("#timeSheetsTheme").val())=="default"){
                                
                                popUpDeleteIcon = "<a href='#' class='ui-btn ui-shadow ui-corner-all ui-icon-delete ui-btn-icon-notext ui-btn-inline ui-nodisc-icon plantEntryDeleteIcon' style='background-color:#375BAA;color:#ffffff;text-shadow:none;border-color:#375BAA;'>Delete</a>";
                              
                              }
                                
                              if($("#timeSheetPlantEntry").prop("checked")==true){
                                //open dialog
                                for (i=0;i<10;i++){
                                $("#timeSheetPlantEntryDialogTableContent").append("<tr>\
                                                                                   <td align='center'>251</td>\
                                                                                   <td align='center'>10</td>\
                                                                                   <td align='center'>25555</td>\
                                                                                   <td>"+popUpDeleteIcon+"</td></tr>");
                                }
                                $("#timeSheetPlantEntryDialog").popup("open");
                                }else{
                                //console.log("unchecked");
                                $("#timeSheetPlantEntryDialogTableContent").empty();
                                $("#timeSheetPlantEntryDialog").popup("close");
                                }
                                });


function closePopUpPlantEntry(){
    $("#timeSheetPlantEntryDialog").popup("option","history",false);
    $("#timeSheetPlantEntryDialogTableContent").empty();
    $("#timeSheetPlantEntryDialog").popup("close");
    $("#timeSheetPlantEntry").prop("checked",false).checkboxradio("refresh");
//    $("#timeSheetNotAnPlantEntry").show();
}


/*View timesheet popup for plant entry*/


function timeSheetViewPlantEntry(linenumber)

{
     for (i=0;i<5;i++){
    $("#timeSheetViewPlantEntryPopupContent").append("<tr>\
                                                     <td align='center'>251</td>\
                                                     <td align='center'>10</td>\
                                                     <td align='center'>25555</td>\
                                                     </tr>");
     }
    
    $("#timeSheetViewPlantEntryPopup").popup("open");
    
}

/*End of View timesheet popup for plant entry*/

function closeViewPopUpPlantEntry(){
    $("#timeSheetViewPlantEntryPopupContent").empty();
    $("#timeSheetViewPlantEntryPopup").popup("close");
}




//$("#timeSheetPlantEntryDialog").on("popupafteropen",function( event, ui ) {
//                                   for (i=0;i<10;i++){
//                                   $("#timeSheetPlantEntryDialogTableContent").append("<tr>\
//                                                       <td align='center'>251</td>\
//                                                       <td align='center'>10</td>\
//                                                       <td align='center'>25555</td>\
//                                                       <td><a href='#' class='ui-btn ui-shadow ui-corner-all ui-icon-delete ui-btn-icon-notext ui-btn-inline ui-nodisc-icon plantEntryDeleteIcon'>Delete</a></td></tr>");
//                                   }
//                                   });


$("#timeSheetViewPlantEntryPopup").on("popupafterclose",function( event, ui ) {
                $("#tablebody").empty();
});



/* End of function */

function timeSheetPreviousPage(){
   
    if(fromPg == "timeSheetButtonPg"){
        changePage("#timeSheetButtonPg","slide",true);
    }else if(fromPg == "timeSheetPg"){
        changePage("#timeSheetPg","slide",true);
    }
}

/*Function to generate timesheet select box values*/

function generateTimeSheetSelectboxValues(page){

    //  selectbox Hours Type Values
    /*--inorder to make back button work from addnew this if condition is included--*/
    
    if(page == "addPg"){
        console.log("no op");
    }else{
    fromPg = $.mobile.activePage.attr("id");
    }
    
    $("#timeSheetSaveIcon").removeClass("ui-disabled");
    $("#timeSheetSaveAndNewIcon").removeClass("ui-disabled");
    $("#timeSheetSubmittedIcon").addClass("ui-disabled");
    $("#timeSheetDeleteIcon").addClass("ui-disabled");
    $("#addTimeSheetPgHoursType").val("");
    $("#addTimeSheetPgJob").val("");
    $("#addTimeSheetPgTask").val("");
    $("#addTimeSheetPgDate").val("");
    $("#timeSheetPlantEntry").prop("checked", false);
    $("#addTimeSheetPgHours").val("");
    $("#addTimeSheetPgComments").val("");
    $("#timeSheetPlantEntryDiv").hide();
    $(".addTimeSheetPgManagerComments").hide();
    $(".ui-input-clear").addClass("ui-nodisc-icon");
    
    hoursTypeListArray = [];
    jobListArray = [];
    taskListArray = [];
    taskListArrayAutoComplete = [];
    
    parameter = "";
    
    timeSheetWebService("POST", "GetPayTransactionTypes", parameter, function(response) {
                        //console.log("GetPayTransactionTypes"+JSON.stringify(response));
                        hoursTypeListArray = [];
                        if (response.GetPayTransactionTypesResult.length!=0 ||response.GetPayTransactionTypesResult.length!=null) {
                        for(i=0;i<response.GetPayTransactionTypesResult.length;i++){
                        hoursTypeListArray[i] = {"value":response.GetPayTransactionTypesResult[i].Value,"data":response.GetPayTransactionTypesResult[i].Name};
                        }
                        hideLoadingIcon();
                        } else {
                        hideLoadingIcon();
                        showAlert("Cannot able to fetch Hours Type.", "Timesheet");
                        }
                        
                        });

    
    //  Selectbox Job value
    timeSheetWebService("POST", "GetJobsList", parameter, function(response) {
//                        console.log("GetJobsList"+JSON.stringify(response));
                        jobListArray = [];
                        if (response.GetJobsListResult.length!=0 ||response.GetJobsListResult.length!=null) {
                        for(i=0;i<response.GetJobsListResult.length;i++){
                        jobListArray[i] = {"value":response.GetJobsListResult[i].Value,"data":response.GetJobsListResult[i].Name};
                        }
                        hideLoadingIcon();
                        } else {
                        hideLoadingIcon();
                        showAlert("Cannot able to fetch Job.", "Timesheet");
                        }
                        
                        });
    
    
    //  Selectbox Task Value
    
    timeSheetWebService("POST", "GetJobTaskList", parameter, function(response) {
                        //console.log("GetJobTaskList"+JSON.stringify(response));
                        taskListArray = [];
                        if (response.GetJobTaskListResult.length!=0 ||response.GetJobTaskListResult.length!=null) {
                        for(i=0;i<response.GetJobTaskListResult.length;i++){
                        taskListArray[i] = {"JobNumber":response.GetJobTaskListResult[i].JobNumber,"Name":response.GetJobTaskListResult[i].Name,"Value":response.GetJobTaskListResult[i].Value};
                        }
//                        alert(JSON.stringify(taskListArray));
                        changePage("#addTimeSheetPg","slide");
                        hideLoadingIcon();
                        } else {
                        hideLoadingIcon();
                        showAlert("Cannot able to fetch Task.", "Timesheet");
                        }
                        });
    
}
  
/*-- Function will be called when focus made on hourstype field and autofocus result will be generated --*/

$("#addTimeSheetPgHoursType").focus(function(){
$("#addTimeSheetPgHoursType").autocomplete({
                                           lookup: hoursTypeListArray
                                           });
                                       });


/*-- Function will be called when focus made on joblist field and autofocus result will be generated --*/

$("#addTimeSheetPgJob").focus(function(){
$("#addTimeSheetPgJob").autocomplete({
                                     lookup: jobListArray,
                                     onInvalidateSelection:onJobChange(),
                                     onSelect: function (suggestion) {
                                     addTimeSheetPgJobChange(suggestion.data);
                                     }
                                     });
                                     });

/*-- Function will be everytime when change made on job field to enter "NO TASK SELECTED" text in task field  --*/

function onJobChange(){
   
    $("#addTimeSheetPgTask").val("NO TASK SELECTED");
}

/*-- Function to fill task data in array where this tasks is based on job selected in job field--*/

function addTimeSheetPgJobChange(jobno) {
    
                                Apploadingicon();
                                taskListArrayAutoComplete = [];
                                j=0;
                               for(i=0;i<taskListArray.length;i++){
                               if(jobno == taskListArray[i].JobNumber){
    taskListArrayAutoComplete[j] = {"value":taskListArray[i].Name+" - "+taskListArray[i].Value,"data":taskListArray[i].Name};
                                   j++;
                               }
                               }
                               hideLoadingIcon();
    
                      }

/*-- Function will be called when focus made on tasklist field and autofocus result will be generated --*/

$("#addTimeSheetPgTask").focus(function(){
$("#addTimeSheetPgTask").autocomplete({
                                      lookup: taskListArrayAutoComplete,
                                       onInvalidateSelection:onTaskChange(),
                                      });
                                  });

/*-- Function will be called whenever changes made on task field --*/

function onTaskChange(){
    $("addTimeSheetPgJob").val("NO JOB SELECTED");
}

/* End of function */

/*-- View Timesheet Function --*/

function viewTimeSheetDetails(lineno){
    
    fromViewPg = 1;
    localStorage.setItem("timeSheetListLineNumber",lineno);
    generateTimeSheetSelectboxValues();
    $("#timeSheetPlantEntryDiv").show();
    
    parameter = {
    "lineNumber":lineno
    }

    timeSheetWebService("POST", "GetTimesheetEntry", parameter, function(response) {
                        //console.log("GetTimesheetEntry"+JSON.stringify(response));
                        if (response.GetTimesheetEntryResult.Status) {
                        /*timesheet status 2 which means that particular timesheet have been submitted already*/
                        if(response.GetTimesheetEntryResult.TimesheetStatus == 1 || response.GetTimesheetEntryResult.TimesheetStatus == 2 || response.GetTimesheetEntryResult.TimesheetStatus == 3){
                        $("#timeSheetSaveIcon").addClass("ui-disabled");
                        $("#timeSheetSaveAndNewIcon").addClass("ui-disabled");
                        $("#timeSheetSubmittedIcon").addClass("ui-disabled");
                        $("#timeSheetPlantEntryDiv").hide();
                        }else{
                        $("#timeSheetSaveIcon").removeClass("ui-disabled");
                        $("#timeSheetSaveAndNewIcon").removeClass("ui-disabled");
                        $("#timeSheetSubmittedIcon").removeClass("ui-disabled");
                        $("#timeSheetDeleteIcon").removeClass("ui-disabled");
                        $("#timeSheetPlantEntryDiv").show();
                        }
                        if(response.GetTimesheetEntryResult.TimesheetStatus == 1 || response.GetTimesheetEntryResult.TimesheetStatus == 2){
                        $("#timeSheetDeleteIcon").addClass("ui-disabled");
                        }
                        
                        if(response.GetTimesheetEntryResult.TimesheetStatus == 3){
                        $(".addTimeSheetPgManagerComments").show();
                        }else{
                        $(".addTimeSheetPgManagerComments").hide();
                        }
                        
                        str = response.GetTimesheetEntryResult.WorkDate;
                        str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                        now = new Date(+str);
                        day = ("0" + now.getDate()).slice(-2);
                        month = ("0" + (now.getMonth() + 1)).slice(-2);
                        fullDate = now.getFullYear()+"-"+month+"-"+day;
                        
                        $("#addTimeSheetPgDate").val(fullDate);
                        $("#addTimeSheetPgHoursType").val(response.GetTimesheetEntryResult.TransactionType);
                        $("#addTimeSheetPgJob").val(response.GetTimesheetEntryResult.JobFullDescription);
                        $("#addTimeSheetPgHours").val(response.GetTimesheetEntryResult.Units);
                        $("#addTimeSheetPgComments").val(response.GetTimesheetEntryResult.EmployeeComments);
                        $("#addTimeSheetPgManagerComments").val(response.GetTimesheetEntryResult.ManagerComments);
                        
                        for(i=0;i<jobListArray.length;i++){
                        if((jobListArray[i].value) == ($("#addTimeSheetPgJob").val())){
                        jobno = jobListArray[i].data;
                        }
                        }
                            taskListArrayAutoComplete = [];
                            j=0;
                            for(i=0;i<taskListArray.length;i++){
                                if(jobno == taskListArray[i].JobNumber){
                                    taskListArrayAutoComplete[j] = {"value":taskListArray[i].Name+" - "+taskListArray[i].Value,"data":taskListArray[i].Name};
                                    j++;
                                }
                            }

                        $("#addTimeSheetPgTask").val(response.GetTimesheetEntryResult.JobTaskFullDescription);
                        //localStorage.setItem("TaskFieldNumber",response.GetTimesheetEntryResult.JobTaskNumber);
                        hideLoadingIcon();
                        changePage("#addTimeSheetPg","slide");
                        } else {
                        hideLoadingIcon();
                        showAlert("Unable to view timesheet details please try again.", "Timesheet");
                        }

                        });

    
}

/*-- End Of View Timesheet Function --*/

/*-- Save, Save&New, Submit Timesheet Listview Function --*/

function timeSheetSaveNew(type){
    
    now = new Date($("#addTimeSheetPgDate").val());
    day = now.getDate();
    if (day<10){
        day = "0"+day;
    }
    month = now.getMonth()+1;
    if(month<10){
        month = "0"+month;
    }
    year = now.getFullYear();
    fullDate = day+"-"+month+"-"+year;
    
    if(($("#addTimeSheetPgDate").val() == "") && ($("#addTimeSheetPgHours").val()=="") && ($("#addTimeSheetPgHoursType").val() == "")) {
        showAlert("Please enter all fields", "Timesheet", function(){
                  $("#addTimeSheetPgDate").focus();
                  });
    }else if($("#addTimeSheetPgHoursType").val()==""){
        showAlert("Please enter hours type", "Timesheet", function(){
                  $("#addTimeSheetPgHoursType").focus();
                  });
    }else if($("#addTimeSheetPgHours").val()==""){
        showAlert("Please enter hours field", "Timesheet", function(){
                  $("#addTimeSheetPgHours").focus();
                  });
    }else{
    
        for(i=0;i<hoursTypeListArray.length;i++){
            if(hoursTypeListArray[i].value == $("#addTimeSheetPgHoursType").val()){
               hoursTypeTextFieldValue  = hoursTypeListArray[i].data;
            }
        }
        
        for(i=0;i<jobListArray.length;i++){
            if(jobListArray[i].value == $("#addTimeSheetPgJob").val()){
                jobListTextFieldValue = jobListArray[i].data;
            }
        }
        
        if((jobListTextFieldValue == null) || (jobListTextFieldValue == "") || (jobListTextFieldValue == undefined)){
           
                jobListTextFieldValue = "NO JOB SELECTED";
        }
        
        if(jobListTextFieldValue == "NO JOB SELECTED"){
            
            taskListTextFieldValue = "NO TASK SELECTED";
            
        }else{
            
        for(i=0;i<taskListArrayAutoComplete.length;i++){
            
            if(($("#addTimeSheetPgTask").val() == "") || ($("#addTimeSheetPgTask").val() == "NO TASK SELECTED")){
                
                taskListTextFieldValue = "NO TASK SELECTED";
                
            }else if(taskListArrayAutoComplete[i].value == $("#addTimeSheetPgTask").val()){
                
                    taskListTextFieldValue = taskListArrayAutoComplete[i].data;
               }
        }
        }
        
//        alert(jobListTextFieldValue+""+taskListTextFieldValue);
//        alert("jobListArray"+JSON.stringify(jobListArray)+"hoursTypeListArray"+JSON.stringify(taskListArrayAutoComplete));
        
    if((type=="saveandnew") || (type=="save")){

        if(fromViewPg==1){

            parameter =
            {"entry":
                {
                    "lineNo":localStorage.getItem("timeSheetListLineNumber"),
                    "JobId": jobListTextFieldValue,
                    "TaskId": taskListTextFieldValue,
                    "EntryDate":fullDate,
                    "Hours":$("#addTimeSheetPgHours").val(),
                    "TransactionType":hoursTypeTextFieldValue,
                    "Comments":$("#addTimeSheetPgComments").val(),
                    "Status":"0",
                    "EmployeeNo":localStorage.getItem("timeSheetEmployeeNumber")
                }
            }
            fromViewPg = 0;
        }else{
            
        parameter =
        {"entry":
            {
                "lineNo":"-1",
                "JobId":jobListTextFieldValue,
                "TaskId":taskListTextFieldValue,
                "EntryDate":fullDate,
                "Hours":$("#addTimeSheetPgHours").val(),
                "TransactionType":hoursTypeTextFieldValue,
                "Comments":$("#addTimeSheetPgComments").val(),
                "Status":"0",
                "EmployeeNo":localStorage.getItem("timeSheetEmployeeNumber")
            }
        }
        }
        console.log("SaveUpdateTimesheetEntryparameter"+JSON.stringify(parameter));
        timeSheetWebService("POST", "SaveUpdateTimesheetEntry", parameter, function(response) {
                            //console.log("SaveTimesheetEntry"+JSON.stringify(response));
                            if(response.SaveUpdateTimesheetEntryResult) {
                            hideLoadingIcon();
                            showAlert("Timesheet added/updated successfully!", "Timesheet", function(){
                                      if(type=="saveandnew"){
                                      generateTimeSheetSelectboxValues('addPg');
                                      $("#addTimeSheetPgDate").val();
                                      $("#addTimeSheetPgHours").val();
                                      $("#addTimeSheetPgComments").val();
                                      $("#addTimeSheetPgHoursType").val("");
                                      $("#addTimeSheetPgJob").val("");
                                      $("#addTimeSheetPgTask").val("");
                                      }else{
                                      if(timeSheetSavedFrom=="daily"){
                                      generateTimeSheetListView('daily');
                                      }else if(timeSheetSavedFrom=="weekly"){
                                      generateTimeSheetListView('weekly');
                                      }else if(timeSheetSavedFrom=="fourtnightly"){
                                      generateTimeSheetListView('fourtnightly');
                                      }else if(timeSheetSavedFrom=="monthly"){
                                      generateTimeSheetListView('monthly');
                                      }else{
                                      generateTimeSheetListView('list');
                                      }
                                      }
                                      hoursTypeTextFieldValue = "";
                                      jobListTextFieldValue = "";
                                      taskListTextFieldValue = "";
                                      });
                            } else {
                            hideLoadingIcon();
                            showAlert("Unable to add timesheet please try again.", "Timesheet");
                            }
                            });

        
    }else if(type=="submit"){
       
        now = new Date();
        day = now.getDate();
        if (day<10){
            day = "0"+day;
        }
        month = now.getMonth()+1;
        if(month<10){
            month = "0"+month;
        }
        year = now.getFullYear();
        submitFullDate = day+"-"+month+"-"+year;
        
        multiplePromptAlert("Timesheet submission period based on?", timeSheetSubmission, "Timesheet", "Current", "Weekly", "Cancel");
        
    }else if(type=="delete"){
        //alert(localStorage.getItem("timeSheetListLineNumber"));
        parameter = {
            "lineNum":localStorage.getItem("timeSheetListLineNumber")
        }

        promptAlert("Are you sure you want to delete this Timesheet?", deleteTimeSheet, "Timesheet", "Yes", "No");
    }
    

//$("input[type=date][name$=addTimeSheetPgDate]").val("");

    
}
}

/*-- End Of Save, Save&New Timesheet Listview Function --*/

/* Function to submit timesheet*/

function timeSheetSubmission(index){
 
    /*-- Individual timesheet submission --*/
    if(index==1){
        
        parameter =
        {   "employeeNumber":localStorage.getItem("timeSheetEmployeeNumber"),
            "submittedDate":submitFullDate,
            "startDate":fullDate,
            "endDate":fullDate,
            "lineNumber":localStorage.getItem("timeSheetListLineNumber")
        }
        
        
        timeSheetWebService("POST", "SubmitEmployeeTimesheetByWeek", parameter, function(response) {
                            //console.log("SubmitEmployeeTimesheetByWeek"+JSON.stringify(response));
                            if(response.SubmitEmployeeTimesheetByWeekResult){
                            hideLoadingIcon();
                            /*-- To generate list after submission base on daily,weekly,fourtnightly & monthly or all --*/
                            showAlert("Timesheet submitted successfully!", "Timesheet", function(){
                                      if(timeSheetSavedFrom=="daily"){
                                      generateTimeSheetListView('daily');
                                      }else if(timeSheetSavedFrom=="weekly"){
                                      generateTimeSheetListView('weekly');
                                      }else if(timeSheetSavedFrom=="fourtnightly"){
                                      generateTimeSheetListView('fourtnightly');
                                      }else if(timeSheetSavedFrom=="monthly"){
                                      generateTimeSheetListView('monthly');
                                      }else{
                                      generateTimeSheetListView('list');
                                      }
                                      //timeSheetSavedFrom = "";
                                      });
                            }else{
                            showAlert("Unable to submit timesheet please try again.", "Timesheet");
                            hideLoadingIcon();
                            }
                            });
      /*-- Weekly timesheet submission --*/
    }else if(index==2){
        
        now = new Date($("#addTimeSheetPgDate").val());
        first = now.getDate() - now.getDay();
        first = new Date(now.setDate(first)).toUTCString();
        firstFullDate = new Date(first);
        lastFullDate = new Date(first);
        
        day = firstFullDate.getDate();
        weeklyStartDate = firstFullDate.getDate();
        if(day<10){
            day = "0"+day;
        }
        
        month = firstFullDate.getMonth()+1;
        if(month<10){
            
            month = "0"+month;
        }
        
        year = firstFullDate.getFullYear();
        firstFullDate = day+"-"+month+"-"+year;
        
        /* Code to find last day of week*/
        
        lastFullDate.setDate(lastFullDate.getDate() + 6);
        day = lastFullDate.getDate();
        month = lastFullDate.getMonth() + 1;
        year = lastFullDate.getFullYear();
        
        if(day<10){
            day = "0"+day;
        }
        
        if(month<10){
            month = "0"+month;
        }
        
        lastFullDate = day+"-"+month+"-"+year;

        
        parameter =
        {   "employeeNumber":localStorage.getItem("timeSheetEmployeeNumber"),
            "submittedDate":submitFullDate,
            "startDate":firstFullDate,
            "endDate":lastFullDate,
            "lineNumber":"0"
        }
        //alert(JSON.stringify(parameter));
        timeSheetWebService("POST", "SubmitEmployeeTimesheetByWeek", parameter, function(response) {
                            //console.log("SubmitEmployeeTimesheetByWeek"+JSON.stringify(response));
                            if(response.SubmitEmployeeTimesheetByWeekResult){
                            hideLoadingIcon();
                            showAlert("Timesheet submitted successfully!", "Timesheet", function(){
                                      if(timeSheetSavedFrom=="daily"){
                                      generateTimeSheetListView('daily');
                                      }else if(timeSheetSavedFrom=="weekly"){
                                      generateTimeSheetListView('weekly');
                                      }else if(timeSheetSavedFrom=="fourtnightly"){
                                      generateTimeSheetListView('fourtnightly');
                                      }else if(timeSheetSavedFrom=="monthly"){
                                      generateTimeSheetListView('monthly');
                                      }else{
                                      generateTimeSheetListView('list');
                                      }
                                      //timeSheetSavedFrom = "";
                                      });
                            }else{
                            showAlert("Unable to submit timesheet please try again.", "Timesheet");
                            hideLoadingIcon();
                            }
                            });

    }else{
        console.log("cancel");
    }
    
}

/*--End of function --*/


/*--Function to delete timesheet only if it is saved or rejected it can be deleted--*/

function deleteTimeSheet(ind){
    if(ind==1){
    timeSheetWebService("POST", "DeleteTimesheetEntry", parameter, function(response) {
                        //console.log(JSON.stringify(response));
                        if(response.DeleteTimesheetEntryResult){
                        hideLoadingIcon();
                        showAlert("Timesheet Deleted Successfully!", "Timesheet", function(){
                                  if(timeSheetSavedFrom=="daily"){
                                  generateTimeSheetListView('daily');
                                  }else if(timeSheetSavedFrom=="weekly"){
                                  generateTimeSheetListView('weekly');
                                  }else if(timeSheetSavedFrom=="fourtnightly"){
                                  generateTimeSheetListView('fourtnightly');
                                  }else if(timeSheetSavedFrom=="monthly"){
                                  generateTimeSheetListView('monthly');
                                  }else{
                                  generateTimeSheetListView('list');
                                  }
                                  //timeSheetSavedFrom = "";
                                  });
                        
                        }else{
                        hideLoadingIcon();
                        showAlert("Unable To Delete Timesheet", "Timesheet");
                        }
                        });
    }else{
        console.log("same pg");
    }

}

/*--End of function --*/

/*--Function to cancel timesheet from view timesheet page--*/

function timeSheetCancel(){
    
    promptAlert("Are you sure you want to cancel the changes?", cancelTimeSheet, "Timesheet", "Yes", "No");
    
}


function cancelTimeSheet(index){
    
    if(index=="1"){
        changePage("#timeSheetPg", "slide", true);
    }else if(index=="2"){
        console("no op");
    }
}


/*--End of function --*/
